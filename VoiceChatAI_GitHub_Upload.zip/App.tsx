import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AuthProvider } from './src/context/AuthContext';
import { VoiceProvider } from './src/context/VoiceContext';
import { RootNavigator } from './src/navigation/RootNavigator';

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar style="light" backgroundColor="#0A0C10" />
      <AuthProvider>
        <VoiceProvider>
          <RootNavigator />
        </VoiceProvider>
      </AuthProvider>
    </SafeAreaProvider>
  );
}
