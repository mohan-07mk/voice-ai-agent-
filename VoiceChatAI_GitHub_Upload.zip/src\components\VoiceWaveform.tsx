import React, { useEffect, useRef } from 'react';
import { View, StyleSheet, Animated } from 'react-native';
import { COLORS } from '../constants/theme';

interface VoiceWaveformProps {
  isRecording?: boolean;
  progress?: number; // 0 to 1
  barCount?: number;
  height?: number;
  color?: string;
}

export const VoiceWaveform: React.FC<VoiceWaveformProps> = ({
  isRecording = false,
  progress = 0,
  barCount = 28,
  height = 36,
  color = COLORS.primary,
}) => {
  // Static height pattern mimicking voice frequencies
  const defaultHeights = [
    0.3, 0.45, 0.2, 0.7, 0.9, 0.5, 0.35, 0.8, 1.0, 0.6,
    0.4, 0.75, 0.85, 0.3, 0.6, 0.95, 0.7, 0.5, 0.4, 0.8,
    0.6, 0.3, 0.65, 0.85, 0.5, 0.4, 0.3, 0.2
  ];

  const animatedValues = useRef(
    Array.from({ length: barCount }, () => new Animated.Value(0.3))
  ).current;

  useEffect(() => {
    let animation: Animated.CompositeAnimation | null = null;

    if (isRecording) {
      const createBarAnimation = (val: Animated.Value, delay: number) => {
        return Animated.loop(
          Animated.sequence([
            Animated.timing(val, {
              toValue: Math.random() * 0.8 + 0.2,
              duration: 200 + Math.random() * 200,
              delay,
              useNativeDriver: false,
            }),
            Animated.timing(val, {
              toValue: 0.15 + Math.random() * 0.3,
              duration: 200 + Math.random() * 200,
              useNativeDriver: false,
            }),
          ])
        );
      };

      const anims = animatedValues.map((val, i) => createBarAnimation(val, i * 20));
      animation = Animated.parallel(anims);
      animation.start();
    } else {
      animatedValues.forEach((val, i) => {
        val.setValue(defaultHeights[i % defaultHeights.length]);
      });
    }

    return () => {
      if (animation) animation.stop();
    };
  }, [isRecording, barCount]);

  const activeIndex = Math.floor(progress * barCount);

  return (
    <View style={[styles.container, { height }]}>
      {animatedValues.map((anim, idx) => {
        const isActive = idx <= activeIndex && progress > 0;
        const barHeight = isRecording
          ? anim.interpolate({
              inputRange: [0, 1],
              outputRange: [height * 0.15, height],
            })
          : height * (defaultHeights[idx % defaultHeights.length] || 0.3);

        return (
          <Animated.View
            key={idx}
            style={[
              styles.bar,
              {
                height: barHeight,
                backgroundColor: isRecording
                  ? COLORS.danger
                  : isActive
                  ? color
                  : COLORS.waveformInactive,
              },
            ]}
          />
        );
      })}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 4,
    gap: 3,
  },
  bar: {
    flex: 1,
    minWidth: 2,
    maxWidth: 4,
    borderRadius: 2,
  },
});
