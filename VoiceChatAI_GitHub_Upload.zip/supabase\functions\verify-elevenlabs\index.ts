import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const rawKey = Deno.env.get('ELEVENLABS_API_KEY');
    const ELEVENLABS_API_KEY = rawKey?.trim().replace(/^["']|["']$/g, '');

    if (!ELEVENLABS_API_KEY) {
      return new Response(
        JSON.stringify({
          valid: false,
          error: "ELEVENLABS_API_KEY secret is not configured in Supabase Edge Function environment."
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );
    }

    // Test voices/add with a 1-second silent WAV
    // Minimal valid WAV header + 100 samples
    const wavHeader = new Uint8Array([
      0x52, 0x49, 0x46, 0x46, // "RIFF"
      0x24, 0x00, 0x00, 0x00, // file size - 8
      0x57, 0x41, 0x56, 0x45, // "WAVE"
      0x66, 0x6d, 0x74, 0x20, // "fmt "
      0x10, 0x00, 0x00, 0x00, // chunk size 16
      0x01, 0x00,             // format 1 (PCM)
      0x01, 0x00,             // 1 channel
      0x44, 0xac, 0x00, 0x00, // 44100 sample rate
      0x88, 0x58, 0x01, 0x00, // byte rate (44100 * 2)
      0x02, 0x00,             // block align 2
      0x10, 0x00,             // bits per sample 16
      0x64, 0x61, 0x74, 0x61, // "data"
      0x00, 0x00, 0x00, 0x00  // data size 0
    ]);
    const blob = new Blob([wavHeader], { type: 'audio/wav' });

    const formData = new FormData();
    formData.append('name', 'Test_Probe_Voice');
    formData.append('files', blob, 'sample.wav');

    const addRes = await fetch('https://api.elevenlabs.io/v1/voices/add', {
      method: 'POST',
      headers: { 'xi-api-key': ELEVENLABS_API_KEY },
      body: formData,
    });
    const addStatus = addRes.status;
    const addDetail = await addRes.text();

    return new Response(
      JSON.stringify({
        voices_add_status: addStatus,
        voices_add_response: addDetail
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ valid: false, error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});
