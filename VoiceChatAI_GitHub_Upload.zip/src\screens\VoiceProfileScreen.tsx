import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
  ScrollView,
} from 'react-native';
import { ArrowLeft, Mic, Trash2, RotateCcw, Volume2, Sparkles, CheckCircle2 } from '../components/Icons';
import { Audio } from 'expo-av';
import { useVoice } from '../context/VoiceContext';
import { supabase } from '../api/supabase';
import { COLORS, SPACING, RADIUS } from '../constants/theme';

export const VoiceProfileScreen: React.FC<{ navigation: any }> = ({ navigation }) => {
  const { voiceProfile, deleteVoiceProfile, loading } = useVoice();
  const [testText, setTestText] = useState('Hello! This is a test of my personalized cloned AI voice.');
  const [testingVoice, setTestingVoice] = useState(false);
  const [testSound, setTestSound] = useState<Audio.Sound | null>(null);

  const handleTestVoice = async () => {
    if (!testText.trim() || !voiceProfile?.elevenlabs_voice_id) return;
    setTestingVoice(true);

    try {
      const { data, error } = await supabase.functions.invoke('generate-voice', {
        body: {
          text: testText.trim(),
          conversation_id: 'test_preview',
          voice_id: voiceProfile.elevenlabs_voice_id,
        },
      });

      if (error || !data?.audio_url) {
        Alert.alert('Test Voice', data?.details || error?.message || 'Failed to generate voice preview.');
        setTestingVoice(false);
        return;
      }

      if (testSound) {
        await testSound.unloadAsync();
      }

      const { sound } = await Audio.Sound.createAsync(
        { uri: data.audio_url },
        { shouldPlay: true }
      );
      setTestSound(sound);
    } catch (err: any) {
      Alert.alert('Error', err.message || 'Could not play voice test.');
    } finally {
      setTestingVoice(false);
    }
  };

  const handleDelete = () => {
    Alert.alert(
      'Delete Voice Profile',
      'Are you sure you want to delete your cloned voice? You will need to record a new sample to recreate it.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            await deleteVoiceProfile();
            navigation.replace('Home');
          },
        },
      ]
    );
  };

  if (!voiceProfile) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
            <ArrowLeft size={22} color={COLORS.textPrimary} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Voice Profile</Text>
        </View>
        <View style={styles.centerContainer}>
          <Text style={styles.emptyText}>No voice profile found.</Text>
          <TouchableOpacity
            style={styles.setupButton}
            onPress={() => navigation.replace('VoiceSetup')}
          >
            <Text style={styles.setupButtonText}>Setup Voice Profile</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <ArrowLeft size={22} color={COLORS.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>AI Voice Profile</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Profile Card */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <View style={styles.micCircle}>
              <Mic size={24} color="#FFFFFF" />
            </View>
            <View style={{ marginLeft: 12, flex: 1 }}>
              <Text style={styles.voiceName}>{voiceProfile.voice_name}</Text>
              <View style={styles.statusRow}>
                <CheckCircle2 size={13} color={COLORS.success} />
                <Text style={styles.statusText}>Active & Verified</Text>
              </View>
            </View>
          </View>

          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>ElevenLabs Voice ID</Text>
            <Text style={styles.detailValue} numberOfLines={1}>
              {voiceProfile.elevenlabs_voice_id}
            </Text>
          </View>

          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Model</Text>
            <Text style={styles.detailValue}>eleven_multilingual_v2 (EN / தமிழ்)</Text>
          </View>
        </View>

        {/* Live Voice Test Section */}
        <View style={styles.testSection}>
          <Text style={styles.sectionTitle}>Test Cloned Voice Live</Text>
          <Text style={styles.sectionSubtitle}>
            Type anything below and tap Speak to hear your cloned voice synthesize speech in real-time.
          </Text>

          <TextInput
            style={styles.testInput}
            value={testText}
            onChangeText={setTestText}
            multiline
            placeholder="Type text to speak..."
            placeholderTextColor={COLORS.textMuted}
          />

          <TouchableOpacity
            style={styles.speakButton}
            onPress={handleTestVoice}
            disabled={testingVoice}
          >
            {testingVoice ? (
              <ActivityIndicator color="#FFFFFF" />
            ) : (
              <>
                <Volume2 size={18} color="#FFFFFF" style={{ marginRight: 8 }} />
                <Text style={styles.speakButtonText}>Speak Text</Text>
              </>
            )}
          </TouchableOpacity>
        </View>

        {/* Actions */}
        <View style={styles.actionsContainer}>
          <TouchableOpacity
            style={styles.recreateButton}
            onPress={() => navigation.navigate('VoiceSetup')}
          >
            <RotateCcw size={18} color={COLORS.primaryLight} style={{ marginRight: 8 }} />
            <Text style={styles.recreateText}>Re-record & Update Clone</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.deleteButton}
            onPress={handleDelete}
            disabled={loading}
          >
            <Trash2 size={18} color={COLORS.danger} style={{ marginRight: 8 }} />
            <Text style={styles.deleteText}>Delete Voice Profile</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingTop: 48,
    paddingBottom: 14,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    backgroundColor: COLORS.surface,
  },
  backButton: {
    padding: 6,
    marginRight: 10,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.textPrimary,
  },
  scrollContent: {
    padding: SPACING.md,
  },
  card: {
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: RADIUS.lg,
    padding: SPACING.md,
    marginBottom: SPACING.lg,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingBottom: 14,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    marginBottom: 12,
  },
  micCircle: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  voiceName: {
    fontSize: 17,
    fontWeight: '700',
    color: COLORS.textPrimary,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
    gap: 4,
  },
  statusText: {
    fontSize: 12,
    color: COLORS.success,
    fontWeight: '600',
  },
  detailRow: {
    marginVertical: 6,
  },
  detailLabel: {
    fontSize: 12,
    color: COLORS.textMuted,
    marginBottom: 2,
  },
  detailValue: {
    fontSize: 14,
    color: COLORS.textSecondary,
    fontWeight: '500',
  },
  testSection: {
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: RADIUS.lg,
    padding: SPACING.md,
    marginBottom: SPACING.lg,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.textPrimary,
    marginBottom: 4,
  },
  sectionSubtitle: {
    fontSize: 13,
    color: COLORS.textSecondary,
    lineHeight: 18,
    marginBottom: 12,
  },
  testInput: {
    backgroundColor: COLORS.surfaceLight,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: RADIUS.md,
    color: COLORS.textPrimary,
    padding: 12,
    minHeight: 70,
    fontSize: 14,
    marginBottom: 12,
  },
  speakButton: {
    backgroundColor: COLORS.primary,
    height: 46,
    borderRadius: RADIUS.md,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  speakButtonText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 15,
  },
  actionsContainer: {
    gap: 12,
  },
  recreateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.surfaceLight,
    borderWidth: 1,
    borderColor: COLORS.border,
    height: 48,
    borderRadius: RADIUS.md,
  },
  recreateText: {
    color: COLORS.primaryLight,
    fontWeight: '600',
    fontSize: 14,
  },
  deleteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(239, 68, 68, 0.25)',
    height: 48,
    borderRadius: RADIUS.md,
  },
  deleteText: {
    color: COLORS.danger,
    fontWeight: '600',
    fontSize: 14,
  },
  centerContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: SPACING.xl,
  },
  emptyText: {
    color: COLORS.textSecondary,
    fontSize: 15,
    marginBottom: 16,
  },
  setupButton: {
    backgroundColor: COLORS.primary,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: RADIUS.md,
  },
  setupButtonText: {
    color: '#FFFFFF',
    fontWeight: '700',
  },
});
