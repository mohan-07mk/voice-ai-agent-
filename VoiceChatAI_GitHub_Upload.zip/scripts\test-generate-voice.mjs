import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://mogjiumubmnorxoqjgxd.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_E8cxgKOlwZ8U9iHGTbyfCg_0p1wY83U';
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

async function testTTS() {
  console.log('Testing generate-voice Edge Function...');
  
  // Sign in as Alice
  const { data: authData, error: authErr } = await supabase.auth.signInWithPassword({
    email: 'alice@voicechat.ai',
    password: 'Password123!'
  });

  if (authErr || !authData.session) {
    console.error('Alice login failed:', authErr);
    return;
  }
  console.log('Alice signed in:', authData.user.id);

  // Invoke generate-voice
  const res = await supabase.functions.invoke('generate-voice', {
    body: {
      text: 'Hello from VoiceChat AI! Text-to-speech test.',
      conversation_id: 'test_conv_123'
    }
  });

  console.log('generate-voice result:', res);
  if (res.data) {
    console.log('Audio URL:', res.data.audio_url);
  }
}

testTTS();

