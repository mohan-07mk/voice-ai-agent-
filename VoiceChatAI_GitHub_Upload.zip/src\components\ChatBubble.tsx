import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Check, CheckCheck, RefreshCw } from './Icons';
import { Message } from '../types';
import { AudioPlayer } from './AudioPlayer';
import { COLORS, RADIUS, SPACING } from '../constants/theme';

interface ChatBubbleProps {
  message: Message;
  isSender: boolean;
  onRetryVoice?: (message: Message) => void;
}

export const ChatBubble: React.FC<ChatBubbleProps> = ({
  message,
  isSender,
  onRetryVoice,
}) => {
  const formatTime = (isoString: string) => {
    try {
      const date = new Date(isoString);
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '';
    }
  };

  const renderStatus = () => {
    if (!isSender) return null;
    if (message.status === 'read') {
      return <CheckCheck size={14} color="#60A5FA" style={styles.statusIcon} />;
    }
    if (message.status === 'delivered') {
      return <CheckCheck size={14} color="#94A3B8" style={styles.statusIcon} />;
    }
    return <Check size={14} color="#94A3B8" style={styles.statusIcon} />;
  };

  return (
    <View style={[styles.container, isSender ? styles.senderRow : styles.receiverRow]}>
      <View
        style={[
          styles.bubble,
          isSender ? styles.senderBubble : styles.receiverBubble,
        ]}
      >
        {/* Text Message Content */}
        <Text style={[styles.messageText, isSender ? styles.senderText : styles.receiverText]}>
          {message.text}
        </Text>

        {/* Embedded Audio Player if voice audio exists */}
        {message.audio_url ? (
          <AudioPlayer
            audioUrl={message.audio_url}
            duration={message.audio_duration}
            isSender={isSender}
          />
        ) : null}

        {/* Voice Generation Retry if voice failed */}
        {!message.audio_url && onRetryVoice && (
          <TouchableOpacity
            style={styles.retryButton}
            onPress={() => onRetryVoice(message)}
          >
            <RefreshCw size={12} color={COLORS.primaryLight} />
            <Text style={styles.retryText}>Generate AI Voice</Text>
          </TouchableOpacity>
        )}

        {/* Timestamp & Status indicators */}
        <View style={styles.footer}>
          <Text style={[styles.timeText, isSender ? styles.senderTime : styles.receiverTime]}>
            {formatTime(message.created_at)}
          </Text>
          {renderStatus()}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginVertical: 4,
    paddingHorizontal: SPACING.md,
    flexDirection: 'row',
  },
  senderRow: {
    justifyContent: 'flex-end',
  },
  receiverRow: {
    justifyContent: 'flex-start',
  },
  bubble: {
    maxWidth: '82%',
    paddingHorizontal: 14,
    paddingTop: 10,
    paddingBottom: 6,
    borderRadius: RADIUS.lg,
  },
  senderBubble: {
    backgroundColor: COLORS.bubbleSent,
    borderBottomRightRadius: 4,
  },
  receiverBubble: {
    backgroundColor: COLORS.bubbleReceived,
    borderBottomLeftRadius: 4,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  messageText: {
    fontSize: 15,
    lineHeight: 21,
    fontFamily: 'System',
  },
  senderText: {
    color: COLORS.bubbleSentText,
  },
  receiverText: {
    color: COLORS.bubbleReceivedText,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    marginTop: 4,
  },
  timeText: {
    fontSize: 11,
    fontFamily: 'System',
  },
  senderTime: {
    color: '#C7D2FE',
  },
  receiverTime: {
    color: COLORS.textMuted,
  },
  statusIcon: {
    marginLeft: 4,
  },
  retryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 6,
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: RADIUS.sm,
    backgroundColor: COLORS.primaryGlow,
    alignSelf: 'flex-start',
    gap: 4,
  },
  retryText: {
    fontSize: 11,
    color: COLORS.primaryLight,
    fontWeight: '600',
  },
});
