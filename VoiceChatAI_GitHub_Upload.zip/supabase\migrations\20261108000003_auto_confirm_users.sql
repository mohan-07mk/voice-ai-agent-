-- Auto-confirm any existing unconfirmed users
update auth.users set email_confirmed_at = coalesce(email_confirmed_at, now()) where email_confirmed_at is null;

-- Trigger to auto-confirm any future signups instantly to prevent email rate-limit blocks
create or replace function public.auto_confirm_user()
returns trigger as $$
begin
  if new.email_confirmed_at is null then
    new.email_confirmed_at := now();
  end if;
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists trigger_auto_confirm_user on auth.users;
create trigger trigger_auto_confirm_user
  before insert on auth.users
  for each row execute procedure public.auto_confirm_user();

