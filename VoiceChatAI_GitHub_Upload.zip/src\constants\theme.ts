export const COLORS = {
  background: '#0A0C10',
  surface: '#121520',
  surfaceLight: '#1B2030',
  border: '#23293D',
  borderLight: '#30374F',
  
  primary: '#6366F1',
  primaryDark: '#4F46E5',
  primaryLight: '#818CF8',
  primaryGlow: 'rgba(99, 102, 241, 0.18)',

  secondary: '#8B5CF6',
  accent: '#06B6D4',

  textPrimary: '#F8FAFC',
  textSecondary: '#94A3B8',
  textMuted: '#64748B',

  bubbleSent: '#4F46E5',
  bubbleReceived: '#181C2A',
  bubbleSentText: '#FFFFFF',
  bubbleReceivedText: '#E2E8F0',

  success: '#10B981',
  danger: '#EF4444',
  warning: '#F59E0B',
  info: '#3B82F6',

  waveformActive: '#818CF8',
  waveformInactive: '#334155',
  waveformBg: '#1E2337',
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 40,
};

export const RADIUS = {
  sm: 6,
  md: 12,
  lg: 18,
  xl: 24,
  full: 9999,
};

export const FONTS = {
  regular: 'System',
  medium: 'System',
  bold: 'System',
};
