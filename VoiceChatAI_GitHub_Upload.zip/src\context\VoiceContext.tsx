import React, { createContext, useContext, useEffect, useState } from 'react';
import { Audio } from 'expo-av';
import * as FileSystem from 'expo-file-system';
import { supabase } from '../api/supabase';
import { useAuth } from './AuthContext';
import { VoiceProfile } from '../types';

interface VoiceContextType {
  voiceProfile: VoiceProfile | null;
  loading: boolean;
  isRecording: boolean;
  recordingUri: string | null;
  recordingDuration: number;
  startRecording: () => Promise<void>;
  stopRecording: () => Promise<string | null>;
  resetRecording: () => void;
  cloneVoiceFromRecording: (name: string) => Promise<{ success: boolean; error?: string; voiceId?: string; notice?: string }>;
  deleteVoiceProfile: () => Promise<void>;
  refreshVoiceProfile: () => Promise<void>;
}

const VoiceContext = createContext<VoiceContextType>({} as VoiceContextType);

export const VoiceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [voiceProfile, setVoiceProfile] = useState<VoiceProfile | null>(null);
  const [loading, setLoading] = useState(false);
  const [recording, setRecording] = useState<Audio.Recording | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingUri, setRecordingUri] = useState<string | null>(null);
  const [recordingDuration, setRecordingDuration] = useState(0);

  const fetchVoiceProfile = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('voice_profiles')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (!error && data) {
        setVoiceProfile(data as VoiceProfile);
      } else {
        setVoiceProfile(null);
      }
    } catch {
      setVoiceProfile(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVoiceProfile();
  }, [user]);

  const startRecording = async () => {
    try {
      const permission = await Audio.requestPermissionsAsync();
      if (!permission.granted) {
        throw new Error('Microphone permission is required to clone your voice.');
      }

      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true,
      });

      const { recording: newRecording } = await Audio.Recording.createAsync(
        Audio.RecordingOptionsPresets.HIGH_QUALITY
      );

      setRecording(newRecording);
      setIsRecording(true);
      setRecordingDuration(0);

      newRecording.setOnRecordingStatusUpdate((status) => {
        if (status.isRecording) {
          setRecordingDuration(Math.floor(status.durationMillis / 1000));
        }
      });
    } catch (err: any) {
      console.error('Failed to start recording', err);
      throw err;
    }
  };

  const stopRecording = async (): Promise<string | null> => {
    if (!recording) return null;
    try {
      setIsRecording(false);
      await recording.stopAndUnloadAsync();
      const uri = recording.getURI();
      setRecordingUri(uri);
      setRecording(null);
      return uri;
    } catch (err) {
      console.error('Failed to stop recording', err);
      setIsRecording(false);
      setRecording(null);
      return null;
    }
  };

  const resetRecording = () => {
    setRecordingUri(null);
    setRecordingDuration(0);
    setIsRecording(false);
    setRecording(null);
  };

  const cloneVoiceFromRecording = async (name: string): Promise<{ success: boolean; error?: string; voiceId?: string; notice?: string }> => {
    if (!user) return { success: false, error: 'User is not authenticated' };
    if (!recordingUri) return { success: false, error: 'No voice recording found. Please record your voice first.' };

    setLoading(true);
    try {
      // 1. Upload audio recording to Supabase Storage 'voice-samples'
      const fileName = `${user.id}/${Date.now()}_sample.m4a`;
      const base64Audio = await FileSystem.readAsStringAsync(recordingUri, {
        encoding: FileSystem.EncodingType.Base64,
      });

      // Convert base64 to byte array buffer for storage upload
      const byteCharacters = atob(base64Audio);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);

      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('voice-samples')
        .upload(fileName, byteArray.buffer, {
          contentType: 'audio/m4a',
          upsert: true,
        });

      if (uploadError) {
        console.warn('Storage direct upload notice:', uploadError.message);
      }

      let audioUrl = '';
      try {
        const { data: signedData } = await supabase.storage
          .from('voice-samples')
          .createSignedUrl(fileName, 3600);
        audioUrl = signedData?.signedUrl || '';
      } catch (signErr) {
        console.warn('Signed url creation notice:', signErr);
      }

      // 2. Invoke Supabase Edge Function 'clone-voice'
      const { data: edgeData, error: edgeError } = await supabase.functions.invoke('clone-voice', {
        body: {
          name,
          storage_path: fileName,
          audio_url: audioUrl,
          audio_base64: base64Audio,
        },
      });

      if (edgeError || !edgeData?.success) {
        let errorMsg = edgeData?.message || edgeData?.error;
        if (!errorMsg && edgeError) {
          try {
            const errorContext = (edgeError as any).context;
            if (errorContext && typeof errorContext.json === 'function') {
              const parsed = await errorContext.json();
              errorMsg = parsed?.details || parsed?.message || parsed?.error;
            }
          } catch {}
          if (!errorMsg) {
            errorMsg = edgeError.message;
          }
        }

        return { success: false, error: errorMsg || 'Failed to clone voice with ElevenLabs' };
      }

      await fetchVoiceProfile();
      return {
        success: true,
        voiceId: edgeData.voice_id,
        notice: edgeData.notice || undefined,
      };
    } catch (err: any) {
      console.error('Voice cloning error:', err);
      return { success: false, error: err.message || 'An error occurred during voice cloning.' };
    } finally {
      setLoading(false);
    }
  };

  const deleteVoiceProfile = async () => {
    if (!user) return;
    setLoading(true);
    try {
      await supabase
        .from('voice_profiles')
        .delete()
        .eq('user_id', user.id);
      setVoiceProfile(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <VoiceContext.Provider
      value={{
        voiceProfile,
        loading,
        isRecording,
        recordingUri,
        recordingDuration,
        startRecording,
        stopRecording,
        resetRecording,
        cloneVoiceFromRecording,
        deleteVoiceProfile,
        refreshVoiceProfile: fetchVoiceProfile,
      }}
    >
      {children}
    </VoiceContext.Provider>
  );
};

export const useVoice = () => useContext(VoiceContext);
