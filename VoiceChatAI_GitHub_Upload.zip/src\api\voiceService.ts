import { supabase } from './supabase';
import { Message, VoiceVerificationResult } from '../types';

export const VoiceService = {
  /**
   * Verify ElevenLabs account status and voice cloning permissions
   */
  async verifyElevenLabs(): Promise<VoiceVerificationResult> {
    try {
      const { data, error } = await supabase.functions.invoke('verify-elevenlabs');
      if (error) {
        return { valid: false, error: error.message };
      }
      return data as VoiceVerificationResult;
    } catch (err: any) {
      return { valid: false, error: err.message || 'Failed to verify ElevenLabs' };
    }
  },

  /**
   * Send a text message and generate AI voice speech using sender's voice profile
   */
  async sendTextMessageWithVoice(
    conversationId: string,
    senderId: string,
    text: string,
    voiceId?: string
  ): Promise<{ message: Message | null; error?: string }> {
    try {
      // 1. Optimistically insert message with 'sending' status
      const { data: insertedMsg, error: insertError } = await supabase
        .from('messages')
        .insert({
          conversation_id: conversationId,
          sender_id: senderId,
          text,
          status: 'sending',
          audio_duration: 0,
        })
        .select()
        .single();

      if (insertError || !insertedMsg) {
        return { message: null, error: insertError?.message || 'Failed to insert message' };
      }

      // 2. Invoke Edge Function 'generate-voice' to synthesize speech with ElevenLabs
      try {
        const { data: genData, error: genError } = await supabase.functions.invoke('generate-voice', {
          body: {
            text,
            conversation_id: conversationId,
            voice_id: voiceId,
          },
        });

        if (genError || !genData?.audio_url) {
          console.warn('Voice generation warning:', genError || genData?.error);
          // Preserve text message even if voice synthesis has an issue
          await supabase
            .from('messages')
            .update({ status: 'sent' })
            .eq('id', insertedMsg.id);

          return {
            message: { ...insertedMsg, status: 'sent' } as Message,
            error: genData?.details || genError?.message,
          };
        }

        // 3. Update message with generated audio URL and duration
        const { data: updatedMsg, error: updateError } = await supabase
          .from('messages')
          .update({
            audio_url: genData.audio_url,
            audio_duration: genData.audio_duration || 0,
            status: 'sent',
          })
          .eq('id', insertedMsg.id)
          .select()
          .single();

        return {
          message: (updatedMsg || insertedMsg) as Message,
        };
      } catch (voiceErr: any) {
        // Preserve text message on voice error
        await supabase
          .from('messages')
          .update({ status: 'sent' })
          .eq('id', insertedMsg.id);

        return {
          message: { ...insertedMsg, status: 'sent' } as Message,
          error: voiceErr.message,
        };
      }
    } catch (err: any) {
      return { message: null, error: err.message };
    }
  },

  /**
   * Retry generating voice for an existing text message
   */
  async retryVoiceGeneration(message: Message, voiceId?: string): Promise<{ audio_url?: string; error?: string }> {
    try {
      const { data: genData, error: genError } = await supabase.functions.invoke('generate-voice', {
        body: {
          text: message.text,
          conversation_id: message.conversation_id,
          voice_id: voiceId,
        },
      });

      if (genError || !genData?.audio_url) {
        return { error: genError?.message || genData?.error || 'Failed to generate voice' };
      }

      await supabase
        .from('messages')
        .update({
          audio_url: genData.audio_url,
          audio_duration: genData.audio_duration || 0,
        })
        .eq('id', message.id);

      return { audio_url: genData.audio_url };
    } catch (err: any) {
      return { error: err.message };
    }
  },
};
