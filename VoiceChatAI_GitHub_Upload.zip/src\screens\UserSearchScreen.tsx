import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
} from 'react-native';
import { Search, ArrowLeft, MessageSquare, Mic } from '../components/Icons';
import { supabase } from '../api/supabase';
import { useAuth } from '../context/AuthContext';
import { Avatar } from '../components/Avatar';
import { Profile } from '../types';
import { COLORS, SPACING, RADIUS } from '../constants/theme';

export const UserSearchScreen: React.FC<{ navigation: any }> = ({ navigation }) => {
  const { user } = useAuth();
  const [query, setQuery] = useState('');
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(false);
  const [creatingChat, setCreatingChat] = useState<string | null>(null);

  const searchUsers = async (searchQuery: string) => {
    if (!user) return;
    setLoading(true);
    try {
      let req = supabase
        .from('profiles')
        .select('*')
        .neq('id', user.id)
        .limit(20);

      if (searchQuery.trim()) {
        req = req.or(`full_name.ilike.%${searchQuery.trim()}%,email.ilike.%${searchQuery.trim()}%`);
      }

      const { data, error } = await req;
      if (!error && data) {
        setUsers(data as Profile[]);
      } else {
        setUsers([]);
      }
    } catch {
      setUsers([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    searchUsers('');
  }, []);

  const handleStartChat = async (targetUser: Profile) => {
    if (!user) return;
    setCreatingChat(targetUser.id);

    try {
      // 1. Check if a conversation between these two users already exists
      const { data: myMemberships } = await supabase
        .from('conversation_members')
        .select('conversation_id')
        .eq('user_id', user.id);

      if (myMemberships && myMemberships.length > 0) {
        const myConvIds = myMemberships.map(m => m.conversation_id);
        const { data: commonMembers } = await supabase
          .from('conversation_members')
          .select('conversation_id')
          .in('conversation_id', myConvIds)
          .eq('user_id', targetUser.id);

        if (commonMembers && commonMembers.length > 0) {
          // Existing conversation found!
          navigation.replace('ChatDetail', {
            conversationId: commonMembers[0].conversation_id,
            otherUser: targetUser,
          });
          return;
        }
      }

      // 2. Create new conversation
      const { data: newConv, error: convError } = await supabase
        .from('conversations')
        .insert({})
        .select()
        .single();

      if (convError || !newConv) {
        throw new Error('Failed to create conversation');
      }

      // 3. Add both members
      await supabase.from('conversation_members').insert([
        { conversation_id: newConv.id, user_id: user.id },
        { conversation_id: newConv.id, user_id: targetUser.id },
      ]);

      navigation.replace('ChatDetail', {
        conversationId: newConv.id,
        otherUser: targetUser,
      });
    } catch (err: any) {
      console.error('Error starting conversation:', err);
    } finally {
      setCreatingChat(null);
    }
  };

  return (
    <View style={styles.container}>
      {/* Top Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <ArrowLeft size={22} color={COLORS.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>New AI Voice Chat</Text>
      </View>

      {/* Search Input */}
      <View style={styles.searchBar}>
        <Search size={18} color={COLORS.textSecondary} style={{ marginRight: 8 }} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search by name or email..."
          placeholderTextColor={COLORS.textMuted}
          value={query}
          onChangeText={(text) => {
            setQuery(text);
            searchUsers(text);
          }}
          autoFocus
        />
      </View>

      {/* Results */}
      {loading ? (
        <View style={styles.centerContainer}>
          <ActivityIndicator size="large" color={COLORS.primary} />
        </View>
      ) : users.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No users found.</Text>
        </View>
      ) : (
        <FlatList
          data={users}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.userItem}
              onPress={() => handleStartChat(item)}
              disabled={creatingChat === item.id}
            >
              <Avatar name={item.full_name} avatarUrl={item.avatar_url} size={44} />
              <View style={styles.userInfo}>
                <Text style={styles.userName}>{item.full_name}</Text>
                <Text style={styles.userStatus} numberOfLines={1}>
                  {item.status_message || item.email}
                </Text>
              </View>

              {creatingChat === item.id ? (
                <ActivityIndicator size="small" color={COLORS.primary} />
              ) : (
                <View style={styles.chatActionIcon}>
                  <MessageSquare size={18} color={COLORS.primaryLight} />
                </View>
              )}
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingTop: 48,
    paddingBottom: 14,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    backgroundColor: COLORS.surface,
  },
  backButton: {
    padding: 6,
    marginRight: 10,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.textPrimary,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: RADIUS.md,
    margin: SPACING.md,
    paddingHorizontal: 12,
    height: 46,
  },
  searchInput: {
    flex: 1,
    color: COLORS.textPrimary,
    fontSize: 14,
  },
  centerContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: SPACING.xl,
  },
  emptyText: {
    color: COLORS.textSecondary,
    fontSize: 14,
  },
  userItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.04)',
  },
  userInfo: {
    flex: 1,
    marginLeft: 12,
  },
  userName: {
    fontSize: 15,
    fontWeight: '600',
    color: COLORS.textPrimary,
  },
  userStatus: {
    fontSize: 12,
    color: COLORS.textMuted,
    marginTop: 2,
  },
  chatActionIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: COLORS.primaryGlow,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
