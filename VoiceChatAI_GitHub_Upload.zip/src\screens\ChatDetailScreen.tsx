import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { ArrowLeft, Send, Sparkles, Mic } from '../components/Icons';
import { supabase } from '../api/supabase';
import { useAuth } from '../context/AuthContext';
import { useVoice } from '../context/VoiceContext';
import { VoiceService } from '../api/voiceService';
import { ChatBubble } from '../components/ChatBubble';
import { Avatar } from '../components/Avatar';
import { Message, Profile, VoiceProfile } from '../types';
import { COLORS, SPACING, RADIUS } from '../constants/theme';

export const ChatDetailScreen: React.FC<{ route: any; navigation: any }> = ({
  route,
  navigation,
}) => {
  const { conversationId, otherUser } = route.params as {
    conversationId: string;
    otherUser: Profile;
  };

  const { user } = useAuth();
  const { voiceProfile } = useVoice();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [otherVoiceProfile, setOtherVoiceProfile] = useState<VoiceProfile | null>(null);

  const flatListRef = useRef<FlatList>(null);

  // Fetch other user's voice profile
  const fetchOtherVoice = async () => {
    if (!otherUser?.id) return;
    try {
      const { data } = await supabase
        .from('voice_profiles')
        .select('*')
        .eq('user_id', otherUser.id)
        .single();

      if (data) setOtherVoiceProfile(data as VoiceProfile);
    } catch {
      // Ignore
    }
  };

  // Fetch messages
  const fetchMessages = async () => {
    try {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .eq('conversation_id', conversationId)
        .order('created_at', { ascending: true });

      if (!error && data) {
        setMessages(data as Message[]);
      }
    } catch (err) {
      console.error('Error fetching messages:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMessages();
    fetchOtherVoice();

    // Setup Supabase Realtime channel
    const channel = supabase
      .channel(`chat_${conversationId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'messages',
          filter: `conversation_id=eq.${conversationId}`,
        },
        (payload) => {
          if (payload.eventType === 'INSERT') {
            const newMsg = payload.new as Message;
            setMessages((prev) => {
              if (prev.some((m) => m.id === newMsg.id)) return prev;
              return [...prev, newMsg];
            });
          } else if (payload.eventType === 'UPDATE') {
            const updatedMsg = payload.new as Message;
            setMessages((prev) =>
              prev.map((m) => (m.id === updatedMsg.id ? updatedMsg : m))
            );
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [conversationId]);

  const handleSendMessage = async () => {
    if (!inputText.trim() || !user || sending) return;

    const textToSend = inputText.trim();
    setInputText('');
    setSending(true);

    try {
      // Send text message and synthesize voice via ElevenLabs
      await VoiceService.sendTextMessageWithVoice(
        conversationId,
        user.id,
        textToSend,
        voiceProfile?.elevenlabs_voice_id
      );
    } catch (err) {
      console.error('Send message error:', err);
    } finally {
      setSending(false);
    }
  };

  const handleRetryVoice = async (msg: Message) => {
    try {
      await VoiceService.retryVoiceGeneration(msg, voiceProfile?.elevenlabs_voice_id);
      fetchMessages();
    } catch (err) {
      console.error('Retry voice error:', err);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
    >
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <ArrowLeft size={22} color={COLORS.textPrimary} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.userProfileLink}
          onPress={() => {}}
          activeOpacity={0.7}
        >
          <Avatar
            name={otherUser.full_name}
            avatarUrl={otherUser.avatar_url}
            size={40}
            hasVoiceClone={Boolean(otherVoiceProfile)}
          />
          <View style={{ marginLeft: 10 }}>
            <Text style={styles.headerName}>{otherUser.full_name}</Text>
            <View style={styles.voiceStatusRow}>
              {otherVoiceProfile ? (
                <>
                  <Sparkles size={11} color={COLORS.primaryLight} style={{ marginRight: 3 }} />
                  <Text style={styles.voiceStatusText}>AI Cloned Voice</Text>
                </>
              ) : (
                <Text style={styles.onlineStatusText}>VoiceChat Member</Text>
              )}
            </View>
          </View>
        </TouchableOpacity>
      </View>

      {/* Message List */}
      {loading ? (
        <View style={styles.centerContainer}>
          <ActivityIndicator size="large" color={COLORS.primary} />
        </View>
      ) : (
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <ChatBubble
              message={item}
              isSender={item.sender_id === user?.id}
              onRetryVoice={handleRetryVoice}
            />
          )}
          contentContainerStyle={styles.listContent}
          onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
        />
      )}

      {/* Bottom Input Bar */}
      <View style={styles.inputContainer}>
        <View style={styles.inputFieldWrapper}>
          <TextInput
            style={styles.textInput}
            placeholder="Type message in English or தமிழ்..."
            placeholderTextColor={COLORS.textMuted}
            value={inputText}
            onChangeText={setInputText}
            multiline
            maxLength={1000}
          />
        </View>

        <TouchableOpacity
          style={[
            styles.sendButton,
            inputText.trim() ? styles.sendButtonActive : styles.sendButtonInactive,
          ]}
          onPress={handleSendMessage}
          disabled={!inputText.trim() || sending}
        >
          {sending ? (
            <ActivityIndicator size="small" color="#FFFFFF" />
          ) : (
            <Send size={18} color="#FFFFFF" style={{ marginLeft: 2 }} />
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingTop: 48,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    backgroundColor: COLORS.surface,
  },
  backButton: {
    padding: 6,
    marginRight: 6,
  },
  userProfileLink: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  headerName: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.textPrimary,
  },
  voiceStatusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 2,
  },
  voiceStatusText: {
    fontSize: 11,
    color: COLORS.primaryLight,
    fontWeight: '600',
  },
  onlineStatusText: {
    fontSize: 11,
    color: COLORS.textMuted,
  },
  centerContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  listContent: {
    paddingVertical: SPACING.md,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: SPACING.md,
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
    backgroundColor: COLORS.surface,
    gap: 8,
  },
  inputFieldWrapper: {
    flex: 1,
    backgroundColor: COLORS.surfaceLight,
    borderRadius: RADIUS.xl,
    paddingHorizontal: 16,
    paddingVertical: Platform.OS === 'ios' ? 10 : 6,
    maxHeight: 120,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  textInput: {
    color: COLORS.textPrimary,
    fontSize: 15,
    minHeight: 28,
  },
  sendButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 2,
  },
  sendButtonActive: {
    backgroundColor: COLORS.primary,
  },
  sendButtonInactive: {
    backgroundColor: '#374151',
  },
});
