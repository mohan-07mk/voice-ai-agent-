import React from 'react';
import Feather from '@expo/vector-icons/Feather';
import Ionicons from '@expo/vector-icons/Ionicons';

interface IconProps {
  size?: number;
  color?: string;
  style?: any;
  fill?: string;
}

export const Mic: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="mic" size={size} color={color} style={style} />
);

export const Square: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="square" size={size} color={color} style={style} />
);

export const Play: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="play" size={size} color={color} style={style} />
);

export const Pause: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="pause" size={size} color={color} style={style} />
);

export const RotateCcw: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="rotate-ccw" size={size} color={color} style={style} />
);

export const Sparkles: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Ionicons name="sparkles" size={size} color={color} style={style} />
);

export const ArrowLeft: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="arrow-left" size={size} color={color} style={style} />
);

export const ArrowRight: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="arrow-right" size={size} color={color} style={style} />
);

export const CheckCircle2: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="check-circle" size={size} color={color} style={style} />
);

export const Check: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="check" size={size} color={color} style={style} />
);

export const CheckCheck: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Ionicons name="checkmark-done" size={size} color={color} style={style} />
);

export const RefreshCw: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="refresh-cw" size={size} color={color} style={style} />
);

export const Volume2: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="volume-2" size={size} color={color} style={style} />
);

export const Trash2: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="trash-2" size={size} color={color} style={style} />
);

export const LogOut: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="log-out" size={size} color={color} style={style} />
);

export const User: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="user" size={size} color={color} style={style} />
);

export const Mail: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="mail" size={size} color={color} style={style} />
);

export const Lock: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="lock" size={size} color={color} style={style} />
);

export const MessageSquarePlus: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="message-square" size={size} color={color} style={style} />
);

export const MessageSquare: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="message-square" size={size} color={color} style={style} />
);

export const Search: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="search" size={size} color={color} style={style} />
);

export const Settings: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="settings" size={size} color={color} style={style} />
);

export const ChevronRight: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="chevron-right" size={size} color={color} style={style} />
);

export const Server: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="server" size={size} color={color} style={style} />
);

export const Cpu: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="cpu" size={size} color={color} style={style} />
);

export const ShieldCheck: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="shield" size={size} color={color} style={style} />
);

export const Info: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="info" size={size} color={color} style={style} />
);

export const Send: React.FC<IconProps> = ({ size = 20, color = '#FFF', style }) => (
  <Feather name="send" size={size} color={color} style={style} />
);
