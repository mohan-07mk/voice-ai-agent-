import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
  ScrollView,
} from 'react-native';
import { Audio } from 'expo-av';
import { Mic, Square, Play, Pause, RotateCcw, Sparkles, ArrowLeft, CheckCircle2 } from '../components/Icons';
import { useVoice } from '../context/VoiceContext';
import { VoiceWaveform } from '../components/VoiceWaveform';
import { COLORS, SPACING, RADIUS } from '../constants/theme';

const SAMPLE_PHRASES = [
  "Hello! I am excited to use VoiceChat AI for personalized voice messaging. My voice clone will speak exactly like me in English and தமிழ்.",
  "The quick brown fox jumps over the lazy dog while the autumn leaves fall gently to the ground.",
  "வணக்கம்! VoiceChat AI வழியாக எனது சொந்த குரலில் பேசும் குரல் செய்திகளை அனுப்புகிறேன்."
];

export const VoiceSetupScreen: React.FC<{ navigation: any }> = ({ navigation }) => {
  const {
    startRecording,
    stopRecording,
    resetRecording,
    cloneVoiceFromRecording,
    isRecording,
    recordingUri,
    recordingDuration,
    loading,
  } = useVoice();

  const [phraseIndex, setPhraseIndex] = useState(0);
  const [sound, setSound] = useState<Audio.Sound | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [voiceName, setVoiceName] = useState('My Personal Voice');

  useEffect(() => {
    return () => {
      if (sound) {
        sound.unloadAsync();
      }
    };
  }, [sound]);

  const handleRecordToggle = async () => {
    try {
      if (isRecording) {
        await stopRecording();
      } else {
        resetRecording();
        if (sound) {
          await sound.unloadAsync();
          setSound(null);
          setIsPlaying(false);
        }
        await startRecording();
      }
    } catch (err: any) {
      Alert.alert('Recording Error', err.message || 'Could not access microphone.');
    }
  };

  const handlePlayPreview = async () => {
    if (!recordingUri) return;
    try {
      if (sound) {
        const status = await sound.getStatusAsync();
        if (status.isLoaded) {
          if (status.isPlaying) {
            await sound.pauseAsync();
            setIsPlaying(false);
          } else {
            await sound.replayAsync();
            setIsPlaying(true);
          }
          return;
        }
      }

      const { sound: newSound } = await Audio.Sound.createAsync(
        { uri: recordingUri },
        { shouldPlay: true },
        (status) => {
          if (status.isLoaded) {
            setIsPlaying(status.isPlaying);
            if (status.didJustFinish) {
              setIsPlaying(false);
            }
          }
        }
      );
      setSound(newSound);
      setIsPlaying(true);
    } catch (err: any) {
      console.error('Preview error', err);
    }
  };

  const handleCloneVoice = async () => {
    if (!recordingUri) {
      Alert.alert('Recording Required', 'Please record a voice sample first.');
      return;
    }

    if (recordingDuration < 3) {
      Alert.alert('Sample Too Short', 'Please record at least 5 seconds of clear speech for accurate voice cloning.');
      return;
    }

    const res = await cloneVoiceFromRecording(voiceName);

    if (res.success) {
      const successMessage = res.notice
        ? `Your AI voice profile has been activated!\n\n${res.notice}`
        : 'Your personalized AI voice profile has been created and verified. From now on, your typed messages will be spoken in your unique cloned voice.';
      Alert.alert(
        'Voice Profile Ready! 🎉',
        successMessage,
        [{ text: 'Go to Chat', onPress: () => navigation.navigate('Home') }]
      );
    } else {
      Alert.alert(
        'Voice Cloning Notice',
        res.error || 'Failed to clone voice with ElevenLabs. Please check your account subscription tier.'
      );
    }
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <ArrowLeft size={22} color={COLORS.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Personal Voice Clone Setup</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Intro */}
        <View style={styles.introCard}>
          <View style={styles.introIcon}>
            <Sparkles size={24} color={COLORS.primaryLight} />
          </View>
          <Text style={styles.introTitle}>Clone Your Real Voice</Text>
          <Text style={styles.introDescription}>
            Read the phrase below clearly into your phone's microphone. ElevenLabs AI will capture your vocal frequencies and create an exact digital clone.
          </Text>
        </View>

        {/* Phrase Card */}
        <View style={styles.phraseCard}>
          <View style={styles.phraseHeader}>
            <Text style={styles.phraseBadge}>SAMPLE PHRASE {phraseIndex + 1}/3</Text>
            <TouchableOpacity
              onPress={() => setPhraseIndex((prev) => (prev + 1) % SAMPLE_PHRASES.length)}
            >
              <Text style={styles.nextPhraseText}>Switch Phrase</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.phraseText}>
            "{SAMPLE_PHRASES[phraseIndex]}"
          </Text>
        </View>

        {/* Waveform Visualizer */}
        <View style={styles.visualizerCard}>
          <VoiceWaveform
            isRecording={isRecording}
            progress={isRecording ? 0 : recordingUri ? 1 : 0}
            height={44}
            barCount={32}
            color={COLORS.primaryLight}
          />
          <Text style={styles.timerText}>
            {isRecording
              ? `Recording: ${recordingDuration}s`
              : recordingUri
              ? `Sample Captured (${recordingDuration}s)`
              : 'Ready to Record'}
          </Text>
        </View>

        {/* Record & Playback Controls */}
        <View style={styles.controlsRow}>
          {recordingUri && !isRecording && (
            <TouchableOpacity style={styles.secondaryButton} onPress={resetRecording}>
              <RotateCcw size={20} color={COLORS.textSecondary} />
              <Text style={styles.secondaryButtonText}>Re-record</Text>
            </TouchableOpacity>
          )}

          <TouchableOpacity
            style={[
              styles.recordButton,
              isRecording ? styles.recordButtonActive : styles.recordButtonIdle,
            ]}
            onPress={handleRecordToggle}
          >
            {isRecording ? (
              <Square size={28} color="#FFFFFF" fill="#FFFFFF" />
            ) : (
              <Mic size={32} color="#FFFFFF" />
            )}
          </TouchableOpacity>

          {recordingUri && !isRecording && (
            <TouchableOpacity style={styles.secondaryButton} onPress={handlePlayPreview}>
              {isPlaying ? (
                <Pause size={20} color={COLORS.primaryLight} />
              ) : (
                <Play size={20} color={COLORS.primaryLight} />
              )}
              <Text style={[styles.secondaryButtonText, { color: COLORS.primaryLight }]}>
                {isPlaying ? 'Pause' : 'Play'}
              </Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Clone Action Button */}
        {recordingUri && !isRecording && (
          <TouchableOpacity
            style={styles.cloneSubmitButton}
            onPress={handleCloneVoice}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#FFFFFF" />
            ) : (
              <>
                <Sparkles size={20} color="#FFFFFF" style={{ marginRight: 8 }} />
                <Text style={styles.cloneSubmitButtonText}>Create AI Voice Clone</Text>
              </>
            )}
          </TouchableOpacity>
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingTop: 48,
    paddingBottom: 14,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    backgroundColor: COLORS.surface,
  },
  backButton: {
    padding: 6,
    marginRight: 10,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.textPrimary,
  },
  scrollContent: {
    padding: SPACING.md,
  },
  introCard: {
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: RADIUS.lg,
    padding: SPACING.md,
    marginBottom: SPACING.md,
    alignItems: 'center',
    textAlign: 'center',
  },
  introIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: COLORS.primaryGlow,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  introTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.textPrimary,
    marginBottom: 6,
  },
  introDescription: {
    fontSize: 13,
    color: COLORS.textSecondary,
    textAlign: 'center',
    lineHeight: 19,
  },
  phraseCard: {
    backgroundColor: COLORS.surfaceLight,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    marginBottom: SPACING.md,
  },
  phraseHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  phraseBadge: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.primaryLight,
    letterSpacing: 0.5,
  },
  nextPhraseText: {
    fontSize: 12,
    color: COLORS.primary,
    fontWeight: '600',
  },
  phraseText: {
    fontSize: 16,
    lineHeight: 24,
    color: COLORS.textPrimary,
    fontStyle: 'italic',
  },
  visualizerCard: {
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    marginBottom: SPACING.xl,
    alignItems: 'center',
  },
  timerText: {
    fontSize: 13,
    color: COLORS.textSecondary,
    marginTop: 10,
    fontWeight: '600',
  },
  controlsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 24,
    marginBottom: SPACING.xl,
  },
  recordButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 8,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
  },
  recordButtonIdle: {
    backgroundColor: COLORS.primary,
    shadowColor: COLORS.primary,
  },
  recordButtonActive: {
    backgroundColor: COLORS.danger,
    shadowColor: COLORS.danger,
  },
  secondaryButton: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 10,
  },
  secondaryButtonText: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 4,
    fontWeight: '600',
  },
  cloneSubmitButton: {
    backgroundColor: COLORS.primary,
    height: 52,
    borderRadius: RADIUS.md,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 4,
  },
  cloneSubmitButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
});
