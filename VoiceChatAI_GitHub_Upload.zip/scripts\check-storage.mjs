import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://mogjiumubmnorxoqjgxd.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_E8cxgKOlwZ8U9iHGTbyfCg_0p1wY83U';
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

async function checkStorage() {
  console.log('Testing voice-samples bucket...');
  const { data: d1, error: e1 } = await supabase.storage.from('voice-samples').list('');
  console.log('voice-samples list:', { data: d1, error: e1 });

  console.log('Testing voice-messages bucket...');
  const { data: d2, error: e2 } = await supabase.storage.from('voice-messages').list('');
  console.log('voice-messages list:', { data: d2, error: e2 });
}

checkStorage();

