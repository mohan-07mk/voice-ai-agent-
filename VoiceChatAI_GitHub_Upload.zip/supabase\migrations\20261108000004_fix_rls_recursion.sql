-- Helper security definer function to avoid infinite RLS recursion on conversation_members
create or replace function public.is_member_of_conversation(c_id uuid)
returns boolean as $$
  select exists (
    select 1 from public.conversation_members
    where conversation_id = c_id and user_id = auth.uid()
  );
$$ language sql security definer stable;

-- Drop existing recursive policies
drop policy if exists "Members can view their conversation memberships" on public.conversation_members;
drop policy if exists "Users can view conversations they are member of" on public.conversations;
drop policy if exists "Conversation members can read messages" on public.messages;
drop policy if exists "Conversation members can insert messages" on public.messages;
drop policy if exists "Message senders can update messages" on public.messages;
drop policy if exists "Members can read conversation audio" on storage.objects;
drop policy if exists "Members can upload conversation audio" on storage.objects;

-- Recreate policies using security definer helper
create policy "Members can view their conversation memberships"
  on public.conversation_members for select
  to authenticated
  using (
    user_id = auth.uid() or
    public.is_member_of_conversation(conversation_id)
  );

create policy "Users can view conversations they are member of"
  on public.conversations for select
  to authenticated
  using (
    public.is_member_of_conversation(id)
  );

create policy "Conversation members can read messages"
  on public.messages for select
  to authenticated
  using (
    public.is_member_of_conversation(conversation_id)
  );

create policy "Conversation members can insert messages"
  on public.messages for insert
  to authenticated
  with check (
    sender_id = auth.uid() and
    public.is_member_of_conversation(conversation_id)
  );

create policy "Message senders can update messages"
  on public.messages for update
  to authenticated
  using (
    public.is_member_of_conversation(conversation_id)
  );

-- Storage policies using security definer
create policy "Members can upload conversation audio"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'voice-messages' and
    public.is_member_of_conversation((storage.foldername(name))[1]::uuid)
  );

create policy "Members can read conversation audio"
  on storage.objects for select
  to authenticated
  using (
    bucket_id = 'voice-messages' and
    public.is_member_of_conversation((storage.foldername(name))[1]::uuid)
  );

