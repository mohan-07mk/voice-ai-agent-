import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://mogjiumubmnorxoqjgxd.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_E8cxgKOlwZ8U9iHGTbyfCg_0p1wY83U';
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

async function checkTables() {
  const tables = ['profiles', 'voice_profiles', 'conversations', 'conversation_members', 'messages'];
  for (const t of tables) {
    const { data, error, count } = await supabase.from(t).select('*', { count: 'exact', head: true });
    console.log(`Table ${t}:`, { error: error?.message || 'OK', count });
  }
}

checkTables();

