-- VoiceChat AI: Private Storage Buckets & Strict Row-Level Security

-- 1. Create PRIVATE Storage Buckets: 'voice-samples' and 'voice-messages'
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values 
  ('voice-samples', 'voice-samples', false, 52428800, array['audio/mpeg', 'audio/mp3', 'audio/m4a', 'audio/wav', 'audio/x-m4a']),
  ('voice-messages', 'voice-messages', false, 52428800, array['audio/mpeg', 'audio/mp3', 'audio/m4a', 'audio/wav', 'audio/x-m4a'])
on conflict (id) do update set public = false;

-- 2. Clear any legacy storage policies for these buckets
drop policy if exists "Authenticated users can upload voice messages" on storage.objects;
drop policy if exists "Anyone can read voice messages" on storage.objects;
drop policy if exists "Authenticated users can upload voice files" on storage.objects;
drop policy if exists "Anyone can read voice files" on storage.objects;
drop policy if exists "Users can upload their own voice samples" on storage.objects;
drop policy if exists "Users can read their own voice samples" on storage.objects;
drop policy if exists "Users can delete their own voice samples" on storage.objects;
drop policy if exists "Members can upload conversation audio" on storage.objects;
drop policy if exists "Members can read conversation audio" on storage.objects;

-- 4. Secure Policies for 'voice-samples' (Private to the user)
-- Path format: <user_id>/<filename>
create policy "Users can upload their own voice samples"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'voice-samples' and
    (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "Users can read their own voice samples"
  on storage.objects for select
  to authenticated
  using (
    bucket_id = 'voice-samples' and
    (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "Users can delete their own voice samples"
  on storage.objects for delete
  to authenticated
  using (
    bucket_id = 'voice-samples' and
    (storage.foldername(name))[1] = auth.uid()::text
  );

-- 5. Secure Policies for 'voice-messages' (Private to conversation members)
-- Path format: <conversation_id>/<filename>
create policy "Members can upload conversation audio"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'voice-messages' and
    exists (
      select 1 from public.conversation_members cm
      where cm.conversation_id::text = (storage.foldername(name))[1]
        and cm.user_id = auth.uid()
    )
  );

create policy "Members can read conversation audio"
  on storage.objects for select
  to authenticated
  using (
    bucket_id = 'voice-messages' and
    exists (
      select 1 from public.conversation_members cm
      where cm.conversation_id::text = (storage.foldername(name))[1]
        and cm.user_id = auth.uid()
    )
  );

