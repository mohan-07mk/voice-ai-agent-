export interface Profile {
  id: string;
  email: string;
  full_name: string;
  avatar_url?: string;
  status_message?: string;
  created_at?: string;
  updated_at?: string;
}

export interface VoiceProfile {
  id: string;
  user_id: string;
  elevenlabs_voice_id: string;
  voice_name: string;
  sample_audio_url?: string;
  status: 'training' | 'ready' | 'failed';
  metadata?: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export interface Conversation {
  id: string;
  created_at: string;
  updated_at: string;
  other_user?: Profile;
  last_message?: Message;
  unread_count?: number;
}

export interface ConversationMember {
  id: string;
  conversation_id: string;
  user_id: string;
  created_at: string;
  profile?: Profile;
}

export interface Message {
  id: string;
  conversation_id: string;
  sender_id: string;
  text: string;
  audio_url?: string | null;
  audio_duration?: number;
  waveform_data?: number[];
  status: 'sending' | 'sent' | 'delivered' | 'read' | 'failed';
  created_at: string;
  sender?: Profile;
}

export interface VoiceVerificationResult {
  valid: boolean;
  tier?: string;
  can_use_instant_voice_cloning?: boolean;
  character_limit?: number;
  character_count?: number;
  has_voice_cloning_permission?: boolean;
  error?: string;
}
