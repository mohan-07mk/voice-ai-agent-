import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const rawKey = Deno.env.get('ELEVENLABS_API_KEY');
    const ELEVENLABS_API_KEY = rawKey?.trim().replace(/^["']|["']$/g, '');
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!ELEVENLABS_API_KEY) {
      return new Response(
        JSON.stringify({ error: "ELEVENLABS_API_KEY is not configured in Supabase secrets." }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Missing Authorization header" }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!);
    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);

    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { text, conversation_id, voice_id: overrideVoiceId } = await req.json();

    if (!text || !conversation_id) {
      return new Response(
        JSON.stringify({ error: "Missing text or conversation_id" }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Identify sender's voice profile
    let targetVoiceId = overrideVoiceId;
    if (!targetVoiceId) {
      const { data: voiceProfile } = await supabase
        .from('voice_profiles')
        .select('elevenlabs_voice_id, status')
        .eq('user_id', user.id)
        .single();

      if (voiceProfile && voiceProfile.elevenlabs_voice_id) {
        targetVoiceId = voiceProfile.elevenlabs_voice_id;
      } else {
        // High quality multilingual default voice (Adam)
        targetVoiceId = 'pNInz6obpgDQGcFmaJgB';
      }
    }

    // Call ElevenLabs Text-to-Speech API
    // Model: eleven_multilingual_v2 (supports English, Tamil, and 27 other languages)
    const ttsUrl = `https://api.elevenlabs.io/v1/text-to-speech/${targetVoiceId}?output_format=mp3_44100_128`;
    const ttsRes = await fetch(ttsUrl, {
      method: 'POST',
      headers: {
        'xi-api-key': ELEVENLABS_API_KEY,
        'Content-Type': 'application/json',
        'Accept': 'audio/mpeg',
      },
      body: JSON.stringify({
        text,
        model_id: 'eleven_multilingual_v2',
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.75,
          style: 0.0,
          use_speaker_boost: true,
        },
      }),
    });

    if (!ttsRes.ok) {
      const errText = await ttsRes.text();
      console.error('ElevenLabs TTS error:', errText);
      return new Response(
        JSON.stringify({
          error: "Failed to generate speech with ElevenLabs",
          details: errText,
          fallback_available: true
        }),
        { status: ttsRes.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const audioArrayBuffer = await ttsRes.arrayBuffer();
    const fileName = `${conversation_id}/${Date.now()}_${user.id.substring(0, 8)}.mp3`;

    // Upload to Supabase Storage: bucket 'voice-messages'
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('voice-messages')
      .upload(fileName, audioArrayBuffer, {
        contentType: 'audio/mpeg',
        upsert: true,
      });

    if (uploadError) {
      console.error('Supabase storage upload error:', uploadError);
      return new Response(
        JSON.stringify({ error: "Failed to save generated audio to storage", details: uploadError }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create signed URL for private bucket (valid for 7 days)
    const { data: signedData, error: signedError } = await supabase.storage
      .from('voice-messages')
      .createSignedUrl(fileName, 60 * 60 * 24 * 7);

    const audioUrl = signedData?.signedUrl || '';

    // Estimate audio duration based on text length (avg 150 words per minute ~ 2.5 words per sec)
    const wordCount = text.trim().split(/\s+/).length;
    const estimatedDuration = Math.max(1, Math.round((wordCount / 2.5) * 10) / 10);

    return new Response(
      JSON.stringify({
        success: true,
        audio_url: audioUrl,
        audio_duration: estimatedDuration,
        voice_id: targetVoiceId,
        text,
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
