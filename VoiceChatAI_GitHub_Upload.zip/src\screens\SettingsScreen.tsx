import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Switch,
  ScrollView,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { ArrowLeft, Server, Cpu, Volume2, ShieldCheck, Info } from '../components/Icons';
import { VoiceService } from '../api/voiceService';
import { isSupabaseConfigured } from '../api/supabase';
import { COLORS, SPACING, RADIUS } from '../constants/theme';

export const SettingsScreen: React.FC<{ navigation: any }> = ({ navigation }) => {
  const [autoPlay, setAutoPlay] = useState(true);
  const [verifyingEleven, setVerifyingEleven] = useState(false);
  const [elevenStatus, setElevenStatus] = useState<string | null>(null);

  const handleVerifyElevenLabs = async () => {
    setVerifyingEleven(true);
    setElevenStatus(null);
    try {
      const result = await VoiceService.verifyElevenLabs();
      if (result.valid) {
        setElevenStatus(
          `Connected! Plan: ${result.tier?.toUpperCase()} | Voice Cloning: ${
            result.can_use_instant_voice_cloning ? 'Enabled ✅' : 'Upgrade Required ⚠️'
          }`
        );
      } else {
        setElevenStatus(`Verification Notice: ${result.error || 'Check Supabase edge secrets'}`);
      }
    } catch (err: any) {
      setElevenStatus(`Error: ${err.message}`);
    } finally {
      setVerifyingEleven(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <ArrowLeft size={22} color={COLORS.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Settings & Diagnostics</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Backend & Cloud Diagnostics */}
        <Text style={styles.sectionHeader}>INFRASTRUCTURE & INTEGRATIONS</Text>

        {/* Supabase Status Card */}
        <View style={styles.card}>
          <View style={styles.row}>
            <View style={styles.iconCircle}>
              <Server size={18} color={COLORS.primaryLight} />
            </View>
            <View style={styles.rowText}>
              <Text style={styles.cardTitle}>Supabase Cloud</Text>
              <Text style={styles.cardSub}>
                {isSupabaseConfigured ? 'Connected (Auth, DB, Realtime, Storage)' : 'Connecting...'}
              </Text>
            </View>
            <View style={[styles.statusDot, { backgroundColor: COLORS.success }]} />
          </View>
        </View>

        {/* ElevenLabs Status Card */}
        <View style={styles.card}>
          <View style={styles.row}>
            <View style={styles.iconCircle}>
              <Cpu size={18} color={COLORS.primaryLight} />
            </View>
            <View style={styles.rowText}>
              <Text style={styles.cardTitle}>ElevenLabs AI Voice</Text>
              <Text style={styles.cardSub}>
                Instant Voice Cloning & Multilingual TTS
              </Text>
            </View>
          </View>

          {elevenStatus && (
            <View style={styles.statusBox}>
              <Text style={styles.statusBoxText}>{elevenStatus}</Text>
            </View>
          )}

          <TouchableOpacity
            style={styles.verifyButton}
            onPress={handleVerifyElevenLabs}
            disabled={verifyingEleven}
          >
            {verifyingEleven ? (
              <ActivityIndicator size="small" color="#FFFFFF" />
            ) : (
              <Text style={styles.verifyButtonText}>Verify ElevenLabs Connection</Text>
            )}
          </TouchableOpacity>
        </View>

        {/* Audio Preferences */}
        <Text style={styles.sectionHeader}>AUDIO PREFERENCES</Text>
        <View style={styles.card}>
          <View style={styles.row}>
            <View style={styles.iconCircle}>
              <Volume2 size={18} color={COLORS.primaryLight} />
            </View>
            <View style={styles.rowText}>
              <Text style={styles.cardTitle}>Auto-play Voice Messages</Text>
              <Text style={styles.cardSub}>Play voice messages when opening chat</Text>
            </View>
            <Switch
              value={autoPlay}
              onValueChange={setAutoPlay}
              thumbColor={autoPlay ? COLORS.primary : '#4B5563'}
              trackColor={{ false: '#374151', true: COLORS.primaryGlow }}
            />
          </View>
        </View>

        {/* Security & RLS */}
        <Text style={styles.sectionHeader}>SECURITY</Text>
        <View style={styles.card}>
          <View style={styles.row}>
            <View style={styles.iconCircle}>
              <ShieldCheck size={18} color={COLORS.success} />
            </View>
            <View style={styles.rowText}>
              <Text style={styles.cardTitle}>Row-Level Security (RLS)</Text>
              <Text style={styles.cardSub}>
                Conversations, profiles and audio are protected. ElevenLabs secret is isolated in Supabase backend.
              </Text>
            </View>
          </View>
        </View>

        {/* App Info */}
        <Text style={styles.sectionHeader}>ABOUT APPLICATION</Text>
        <View style={styles.card}>
          <View style={styles.row}>
            <View style={styles.iconCircle}>
              <Info size={18} color={COLORS.textSecondary} />
            </View>
            <View style={styles.rowText}>
              <Text style={styles.cardTitle}>VoiceChat AI</Text>
              <Text style={styles.cardSub}>Version 1.0.0 (Release Build)</Text>
              <Text style={styles.cardSub}>Package: com.voicechatai.app</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingTop: 48,
    paddingBottom: 14,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    backgroundColor: COLORS.surface,
  },
  backButton: {
    padding: 6,
    marginRight: 10,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.textPrimary,
  },
  scrollContent: {
    padding: SPACING.md,
    paddingBottom: 40,
  },
  sectionHeader: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.textMuted,
    letterSpacing: 0.8,
    marginBottom: 8,
    marginTop: 16,
    paddingHorizontal: 4,
  },
  card: {
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    marginBottom: 8,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: COLORS.surfaceLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rowText: {
    flex: 1,
    marginLeft: 12,
  },
  cardTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: COLORS.textPrimary,
  },
  cardSub: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 2,
    lineHeight: 16,
  },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  verifyButton: {
    backgroundColor: COLORS.primary,
    height: 40,
    borderRadius: RADIUS.sm,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 12,
  },
  verifyButtonText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 13,
  },
  statusBox: {
    marginTop: 10,
    padding: 8,
    backgroundColor: COLORS.surfaceLight,
    borderRadius: RADIUS.sm,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  statusBoxText: {
    fontSize: 12,
    color: COLORS.primaryLight,
    lineHeight: 16,
  },
});
