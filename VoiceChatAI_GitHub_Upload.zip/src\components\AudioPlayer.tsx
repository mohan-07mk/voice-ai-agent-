import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { Audio } from 'expo-av';
import { Play, Pause } from './Icons';
import { VoiceWaveform } from './VoiceWaveform';
import { COLORS, SPACING, RADIUS } from '../constants/theme';

interface AudioPlayerProps {
  audioUrl: string;
  duration?: number;
  isSender?: boolean;
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({
  audioUrl,
  duration = 0,
  isSender = false,
}) => {
  const [sound, setSound] = useState<Audio.Sound | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [positionMillis, setPositionMillis] = useState(0);
  const [durationMillis, setDurationMillis] = useState(duration * 1000);

  const isMounted = useRef(true);

  useEffect(() => {
    isMounted.current = true;
    return () => {
      isMounted.current = false;
      if (sound) {
        sound.unloadAsync();
      }
    };
  }, [sound]);

  const loadAndTogglePlay = async () => {
    try {
      if (sound) {
        const status = await sound.getStatusAsync();
        if (status.isLoaded) {
          if (status.isPlaying) {
            await sound.pauseAsync();
            setIsPlaying(false);
          } else {
            if (status.positionMillis >= (status.durationMillis || 0)) {
              await sound.replayAsync();
            } else {
              await sound.playAsync();
            }
            setIsPlaying(true);
          }
          return;
        }
      }

      // Load new sound
      setIsLoading(true);
      await Audio.setAudioModeAsync({
        playsInSilentModeIOS: true,
        staysActiveInBackground: false,
        shouldDuckAndroid: true,
      });

      const { sound: newSound } = await Audio.Sound.createAsync(
        { uri: audioUrl },
        { shouldPlay: true },
        (status) => {
          if (!isMounted.current) return;
          if (status.isLoaded) {
            setPositionMillis(status.positionMillis);
            if (status.durationMillis) {
              setDurationMillis(status.durationMillis);
            }
            setIsPlaying(status.isPlaying);
            if (status.didJustFinish) {
              setIsPlaying(false);
              setPositionMillis(0);
            }
          }
        }
      );

      setSound(newSound);
      setIsPlaying(true);
      setIsLoading(false);
    } catch (error) {
      console.error('Audio playback error', error);
      setIsLoading(false);
      setIsPlaying(false);
    }
  };

  const progress = durationMillis > 0 ? positionMillis / durationMillis : 0;

  const formatTime = (millis: number) => {
    const totalSecs = Math.floor(millis / 1000);
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <View style={[styles.container, isSender ? styles.senderContainer : styles.receiverContainer]}>
      <TouchableOpacity
        style={[styles.playButton, isSender ? styles.senderPlayButton : styles.receiverPlayButton]}
        onPress={loadAndTogglePlay}
        disabled={isLoading}
      >
        {isLoading ? (
          <ActivityIndicator size="small" color={COLORS.textPrimary} />
        ) : isPlaying ? (
          <Pause size={18} color={COLORS.textPrimary} fill={COLORS.textPrimary} />
        ) : (
          <Play size={18} color={COLORS.textPrimary} fill={COLORS.textPrimary} />
        )}
      </TouchableOpacity>

      <View style={styles.waveformWrapper}>
        <VoiceWaveform
          progress={progress}
          color={isSender ? '#C7D2FE' : COLORS.primaryLight}
          height={26}
          barCount={22}
        />
        <View style={styles.timeRow}>
          <Text style={[styles.timeText, isSender ? styles.senderTimeText : styles.receiverTimeText]}>
            {formatTime(positionMillis > 0 ? positionMillis : durationMillis)}
          </Text>
          <Text style={[styles.badgeText, isSender ? styles.senderBadge : styles.receiverBadge]}>
            AI Voice
          </Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
    paddingHorizontal: 8,
    borderRadius: RADIUS.md,
    marginTop: 6,
  },
  senderContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.12)',
  },
  receiverContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
  },
  playButton: {
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  senderPlayButton: {
    backgroundColor: COLORS.primaryDark,
  },
  receiverPlayButton: {
    backgroundColor: COLORS.primary,
  },
  waveformWrapper: {
    flex: 1,
    justifyContent: 'center',
  },
  timeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 4,
  },
  timeText: {
    fontSize: 11,
    fontFamily: 'System',
    fontWeight: '500',
  },
  senderTimeText: {
    color: '#E0E7FF',
  },
  receiverTimeText: {
    color: COLORS.textSecondary,
  },
  badgeText: {
    fontSize: 9,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    paddingHorizontal: 5,
    paddingVertical: 1,
    borderRadius: 4,
  },
  senderBadge: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    color: '#FFFFFF',
  },
  receiverBadge: {
    backgroundColor: COLORS.primaryGlow,
    color: COLORS.primaryLight,
  },
});
