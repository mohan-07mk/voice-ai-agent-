import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://mogjiumubmnorxoqjgxd.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_E8cxgKOlwZ8U9iHGTbyfCg_0p1wY83U';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

async function check() {
  console.log('--- Checking Supabase & ElevenLabs Status ---');
  
  // 1. Invoke verify-elevenlabs
  try {
    const { data, error } = await supabase.functions.invoke('verify-elevenlabs');
    console.log('verify-elevenlabs result:', { data, error });
  } catch (err) {
    console.error('verify-elevenlabs exception:', err);
  }

  // 2. Check storage buckets
  try {
    const { data: buckets, error: bErr } = await supabase.storage.listBuckets();
    console.log('Buckets:', { buckets, bErr });
  } catch (err) {
    console.error('listBuckets exception:', err);
  }
}

check();

