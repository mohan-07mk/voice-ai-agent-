import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://mogjiumubmnorxoqjgxd.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_E8cxgKOlwZ8U9iHGTbyfCg_0p1wY83U';
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

async function setupUsers() {
  console.log('--- Setting up Alice & Bob Test Accounts ---');

  const users = [
    { email: 'alice@voicechat.ai', password: 'Password123!', name: 'Alice VoiceChat' },
    { email: 'bob@voicechat.ai', password: 'Password123!', name: 'Bob VoiceChat' }
  ];

  for (const u of users) {
    // Attempt sign in first
    let { data: signInData, error: signInErr } = await supabase.auth.signInWithPassword({
      email: u.email,
      password: u.password
    });

    if (signInData?.user) {
      console.log(`✅ ${u.name} already exists and signed in successfully! User ID: ${signInData.user.id}`);
      // Ensure profile exists
      await supabase.from('profiles').upsert({
        id: signInData.user.id,
        email: u.email,
        full_name: u.name,
        status_message: 'Using VoiceChat AI'
      });
      await supabase.auth.signOut();
      continue;
    }

    // If not existing, sign up
    console.log(`Registering ${u.name}...`);
    const { data: signUpData, error: signUpErr } = await supabase.auth.signUp({
      email: u.email,
      password: u.password,
      options: {
        data: { full_name: u.name }
      }
    });

    if (signUpErr) {
      console.error(`❌ Failed to sign up ${u.name}:`, signUpErr.message);
    } else {
      console.log(`✅ ${u.name} registered successfully! User ID: ${signUpData.user?.id}`);
      if (signUpData.user) {
        await supabase.from('profiles').upsert({
          id: signUpData.user.id,
          email: u.email,
          full_name: u.name,
          status_message: 'Using VoiceChat AI'
        });
      }
    }
  }
}

setupUsers();

