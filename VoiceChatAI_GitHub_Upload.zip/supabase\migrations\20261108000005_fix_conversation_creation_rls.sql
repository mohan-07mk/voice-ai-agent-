-- Add created_by column to conversations with default auth.uid()
alter table public.conversations add column if not exists created_by uuid references public.profiles(id) default auth.uid();

-- Drop existing conversation and membership policies
drop policy if exists "Users can view conversations they are member of" on public.conversations;
drop policy if exists "Authenticated users can create conversations" on public.conversations;
drop policy if exists "Members can view their conversation memberships" on public.conversation_members;
drop policy if exists "Users can add members to conversation" on public.conversation_members;

-- Conversations Select: Creator or any member can view
create policy "Users can view conversations they are member of"
  on public.conversations for select
  to authenticated
  using (
    created_by = auth.uid() or
    public.is_member_of_conversation(id)
  );

-- Conversations Insert: Any authenticated user can create
create policy "Authenticated users can create conversations"
  on public.conversations for insert
  to authenticated
  with check (true);

-- Conversation Members Select: User themselves, conversation members, or conversation creator
create policy "Members can view their conversation memberships"
  on public.conversation_members for select
  to authenticated
  using (
    user_id = auth.uid() or
    public.is_member_of_conversation(conversation_id) or
    exists (
      select 1 from public.conversations c
      where c.id = conversation_members.conversation_id and c.created_by = auth.uid()
    )
  );

-- Conversation Members Insert: Any authenticated user can add members
create policy "Users can add members to conversation"
  on public.conversation_members for insert
  to authenticated
  with check (true);

