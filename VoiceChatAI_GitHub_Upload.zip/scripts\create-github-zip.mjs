import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

const ROOT_DIR = process.cwd();
const STAGING_DIR = path.join(ROOT_DIR, 'staging_github_repo');
const TARGET_PROJECT_DIR = path.join(STAGING_DIR, 'VoiceChatAI');
const OUTPUT_ZIP = path.join(ROOT_DIR, 'VoiceChatAI_GitHub_Upload.zip');

console.log('Preparing GitHub upload package...');

// Clean existing staging
if (fs.existsSync(STAGING_DIR)) {
  fs.rmSync(STAGING_DIR, { recursive: true, force: true });
}
if (fs.existsSync(OUTPUT_ZIP)) {
  fs.rmSync(OUTPUT_ZIP, { force: true });
}

fs.mkdirSync(TARGET_PROJECT_DIR, { recursive: true });

// Copy function with exclusions
function copyDirectory(src, dest, ignoreList) {
  if (!fs.existsSync(dest)) {
    fs.mkdirSync(dest, { recursive: true });
  }

  const entries = fs.readdirSync(src, { withFileTypes: true });

  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);

    if (ignoreList.includes(entry.name)) {
      continue;
    }

    if (entry.isDirectory()) {
      if (entry.name === 'node_modules' || entry.name === '.expo' || entry.name === '.git' || 
          entry.name === '.vscode' || entry.name === 'dist' || entry.name === '.gradle' || 
          entry.name === 'build' || entry.name === '.temp' || entry.name === 'release' || entry.name === 'staging_github_repo') {
        continue;
      }
      copyDirectory(srcPath, destPath, ignoreList);
    } else {
      if (entry.name.endsWith('.apk') || entry.name.endsWith('.aab') || entry.name === '.env') {
        continue;
      }
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

const rootIgnores = [
  'node_modules',
  '.expo',
  '.git',
  '.vscode',
  'dist',
  'release',
  'staging_github_repo',
  'VoiceChatAI_GitHub_Upload.zip',
  '.env',
  '.temp'
];

copyDirectory(ROOT_DIR, TARGET_PROJECT_DIR, rootIgnores);

console.log('Files staged successfully. Compressing to zip archive using .NET ZipFile...');

// Use .NET ZipFile directly via PowerShell without Write-Progress
try {
  execSync(`powershell -NoProfile -Command "Add-Type -AssemblyName System.IO.Compression.FileSystem; [System.IO.Compression.ZipFile]::CreateFromDirectory('${TARGET_PROJECT_DIR}', '${OUTPUT_ZIP}')"`, {
    stdio: 'inherit'
  });
  console.log(`✅ GitHub Zip created successfully at: ${OUTPUT_ZIP}`);
} catch (err) {
  console.error('Failed with .NET ZipFile, trying tar:', err);
  execSync(`tar -acf "${OUTPUT_ZIP}" -C "${STAGING_DIR}" VoiceChatAI`, { stdio: 'inherit' });
}

// Clean up staging directory
if (fs.existsSync(STAGING_DIR)) {
  fs.rmSync(STAGING_DIR, { recursive: true, force: true });
}

const stats = fs.statSync(OUTPUT_ZIP);
console.log(`📦 Archive Size: ${(stats.size / (1024 * 1024)).toFixed(2)} MB`);
