import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const rawKey = Deno.env.get('ELEVENLABS_API_KEY');
    const ELEVENLABS_API_KEY = rawKey?.trim().replace(/^["']|["']$/g, '');
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!ELEVENLABS_API_KEY) {
      return new Response(
        JSON.stringify({ error: "ELEVENLABS_API_KEY is not configured in Supabase secrets." }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verify user authorization from header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Missing Authorization header" }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!);
    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);

    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Parse payload
    const contentType = req.headers.get('content-type') || '';
    let voiceName = `${user.email?.split('@')[0] || 'User'}'s AI Voice`;
    let sampleBlob: Blob | null = null;
    let sampleAudioUrl = '';

    if (contentType.includes('multipart/form-data')) {
      const formData = await req.formData();
      const name = formData.get('name') as string;
      if (name) voiceName = name;
      const file = formData.get('file') as File;
      if (file) sampleBlob = file;
    } else {
      const body = await req.json();
      if (body.name) voiceName = body.name;
      if (body.audio_url) sampleAudioUrl = body.audio_url;

      // 1. If storage_path provided, download directly with Service Role permissions
      if (body.storage_path) {
        const { data: downloadedBlob, error: dlErr } = await supabase.storage
          .from('voice-samples')
          .download(body.storage_path);

        if (!dlErr && downloadedBlob) {
          sampleBlob = downloadedBlob;
        } else {
          console.warn('Direct storage download notice:', dlErr?.message);
        }
      }

      // 2. If no blob yet and audio_base64 provided
      if (!sampleBlob && body.audio_base64) {
        try {
          const binaryStr = atob(body.audio_base64);
          const bytes = new Uint8Array(binaryStr.length);
          for (let i = 0; i < binaryStr.length; i++) {
            bytes[i] = binaryStr.charCodeAt(i);
          }
          sampleBlob = new Blob([bytes], { type: 'audio/m4a' });
        } catch (b64Err) {
          console.warn('Base64 decode notice:', b64Err);
        }
      }

      // 3. Fallback: fetch from signed audio_url if blob still not obtained
      if (!sampleBlob && body.audio_url) {
        try {
          const audioFetch = await fetch(body.audio_url);
          if (audioFetch.ok) {
            sampleBlob = await audioFetch.blob();
          }
        } catch (fetchErr) {
          console.warn('Audio URL fetch notice:', fetchErr);
        }
      }
    }

    let finalVoiceId = 'pNInz6obpgDQGcFmaJgB'; // Default high quality Adam voice
    let isInstantCloned = false;
    let tierNotice = '';

    // Attempt ElevenLabs Instant Voice Cloning if audio sample is present
    if (sampleBlob) {
      const elevenFormData = new FormData();
      elevenFormData.append('name', voiceName);
      elevenFormData.append('description', `Voice profile for user ${user.id}`);
      elevenFormData.append('files', sampleBlob, 'voice_sample.m4a');

      const cloneRes = await fetch('https://api.elevenlabs.io/v1/voices/add', {
        method: 'POST',
        headers: { 'xi-api-key': ELEVENLABS_API_KEY },
        body: elevenFormData,
      });

      if (cloneRes.ok) {
        const cloneData = await cloneRes.json();
        finalVoiceId = cloneData.voice_id;
        isInstantCloned = true;
      } else {
        const errDetail = await cloneRes.text();
        console.warn('ElevenLabs voices/add response:', cloneRes.status, errDetail);

        if (errDetail.includes('can_not_use_instant_voice_cloning') || errDetail.includes('paid_plan_required')) {
          tierNotice = 'ElevenLabs Free plan does not include custom voice cloning (requires ElevenLabs Starter plan at $5/mo). Voice profile initialized with ElevenLabs HD Voice.';
          isInstantCloned = false;
        } else {
          // If any other unexpected error from ElevenLabs
          return new Response(
            JSON.stringify({
              error: "ElevenLabs voice cloning request failed",
              details: errDetail
            }),
            { status: cloneRes.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
      }
    } else {
      // If no sample was uploaded, inform the user
      return new Response(
        JSON.stringify({ error: "No voice sample audio found. Please record your voice sample and try again." }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Save or update voice profile in database
    const { data: voiceProfile, error: dbError } = await supabase
      .from('voice_profiles')
      .upsert({
        user_id: user.id,
        elevenlabs_voice_id: finalVoiceId,
        voice_name: voiceName,
        sample_audio_url: sampleAudioUrl,
        status: 'ready',
        metadata: {
          instant_cloned: isInstantCloned,
          tier_notice: tierNotice || null,
        },
        updated_at: new Date().toISOString()
      }, { onConflict: 'user_id' })
      .select()
      .single();

    if (dbError) {
      return new Response(
        JSON.stringify({ error: "Voice created but failed to save in database", details: dbError.message }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({
        success: true,
        voice_id: finalVoiceId,
        voice_name: voiceName,
        is_instant_cloned: isInstantCloned,
        notice: tierNotice || null,
        profile: voiceProfile
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
