-- VoiceChat AI Database Schema & RLS Migrations

-- 1. PROFILES TABLE
create table if not exists public.profiles (
  id uuid references auth.users(id) on delete cascade primary key,
  email text,
  full_name text not null default 'VoiceChat User',
  avatar_url text,
  status_message text default 'Using VoiceChat AI',
  created_at timestamptz default now() not null,
  updated_at timestamptz default now() not null
);

-- Enable RLS on profiles
alter table public.profiles enable row level security;

-- Profiles Policies
create policy "Public profiles are viewable by authenticated users"
  on public.profiles for select
  to authenticated
  using (true);

create policy "Users can insert their own profile"
  on public.profiles for insert
  to authenticated
  with check (auth.uid() = id);

create policy "Users can update their own profile"
  on public.profiles for update
  to authenticated
  using (auth.uid() = id);

-- Auto create profile on auth signup trigger
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, full_name, avatar_url)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
    coalesce(new.raw_user_meta_data->>'avatar_url', '')
  );
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();


-- 2. VOICE PROFILES TABLE
create table if not exists public.voice_profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade not null unique,
  elevenlabs_voice_id text not null,
  voice_name text not null default 'My Cloned Voice',
  sample_audio_url text,
  status text not null default 'ready' check (status in ('training', 'ready', 'failed')),
  metadata jsonb default '{}'::jsonb,
  created_at timestamptz default now() not null,
  updated_at timestamptz default now() not null
);

-- Enable RLS on voice_profiles
alter table public.voice_profiles enable row level security;

-- Voice Profiles Policies:
-- Users can see their own voice profile and others' voice profiles when conversing
create policy "Authenticated users can view voice profiles"
  on public.voice_profiles for select
  to authenticated
  using (true);

create policy "Users can manage their own voice profile"
  on public.voice_profiles for insert
  to authenticated
  with check (auth.uid() = user_id);

create policy "Users can update their own voice profile"
  on public.voice_profiles for update
  to authenticated
  using (auth.uid() = user_id);

create policy "Users can delete their own voice profile"
  on public.voice_profiles for delete
  to authenticated
  using (auth.uid() = user_id);


-- 3. CONVERSATIONS TABLE
create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now() not null,
  updated_at timestamptz default now() not null
);

-- Enable RLS on conversations
alter table public.conversations enable row level security;


-- 4. CONVERSATION MEMBERS TABLE
create table if not exists public.conversation_members (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid references public.conversations(id) on delete cascade not null,
  user_id uuid references public.profiles(id) on delete cascade not null,
  created_at timestamptz default now() not null,
  unique (conversation_id, user_id)
);

-- Enable RLS on conversation_members
alter table public.conversation_members enable row level security;

-- Conversation Members Policies
create policy "Members can view their conversation memberships"
  on public.conversation_members for select
  to authenticated
  using (
    user_id = auth.uid() or
    conversation_id in (
      select cm.conversation_id from public.conversation_members cm where cm.user_id = auth.uid()
    )
  );

create policy "Users can add members to conversation"
  on public.conversation_members for insert
  to authenticated
  with check (true);

-- Conversations Policies
create policy "Users can view conversations they are member of"
  on public.conversations for select
  to authenticated
  using (
    exists (
      select 1 from public.conversation_members cm
      where cm.conversation_id = conversations.id and cm.user_id = auth.uid()
    )
  );

create policy "Authenticated users can create conversations"
  on public.conversations for insert
  to authenticated
  with check (true);


-- 5. MESSAGES TABLE
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid references public.conversations(id) on delete cascade not null,
  sender_id uuid references public.profiles(id) on delete cascade not null,
  text text not null,
  audio_url text,
  audio_duration numeric default 0,
  waveform_data jsonb default '[]'::jsonb,
  status text not null default 'sent' check (status in ('sending', 'sent', 'delivered', 'read', 'failed')),
  created_at timestamptz default now() not null
);

-- Enable RLS on messages
alter table public.messages enable row level security;

-- Messages Policies
create policy "Conversation members can read messages"
  on public.messages for select
  to authenticated
  using (
    exists (
      select 1 from public.conversation_members cm
      where cm.conversation_id = messages.conversation_id and cm.user_id = auth.uid()
    )
  );

create policy "Conversation members can insert messages"
  on public.messages for insert
  to authenticated
  with check (
    sender_id = auth.uid() and
    exists (
      select 1 from public.conversation_members cm
      where cm.conversation_id = messages.conversation_id and cm.user_id = auth.uid()
    )
  );

create policy "Message senders can update messages"
  on public.messages for update
  to authenticated
  using (
    exists (
      select 1 from public.conversation_members cm
      where cm.conversation_id = messages.conversation_id and cm.user_id = auth.uid()
    )
  );


-- 6. REALTIME REPLICATION
alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.conversations;
alter publication supabase_realtime add table public.profiles;
alter publication supabase_realtime add table public.voice_profiles;


-- 7. STORAGE BUCKETS
insert into storage.buckets (id, name, public)
values ('voice-messages', 'voice-messages', true)
on conflict (id) do update set public = true;

insert into storage.buckets (id, name, public)
values ('voice-samples', 'voice-samples', true)
on conflict (id) do update set public = true;

-- Storage Policies
create policy "Authenticated users can upload voice messages"
  on storage.objects for insert
  to authenticated
  with check (bucket_id in ('voice-messages', 'voice-samples'));

create policy "Anyone can read voice messages"
  on storage.objects for select
  to authenticated
  using (bucket_id in ('voice-messages', 'voice-samples'));
