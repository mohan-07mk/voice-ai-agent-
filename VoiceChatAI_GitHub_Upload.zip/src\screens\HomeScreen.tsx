import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { MessageSquarePlus, Search, Settings, Mic, CheckCircle2, ChevronRight } from '../components/Icons';
import { supabase } from '../api/supabase';
import { useAuth } from '../context/AuthContext';
import { useVoice } from '../context/VoiceContext';
import { Avatar } from '../components/Avatar';
import { Conversation, Profile } from '../types';
import { COLORS, SPACING, RADIUS } from '../constants/theme';

export const HomeScreen: React.FC<{ navigation: any }> = ({ navigation }) => {
  const { user, profile } = useAuth();
  const { voiceProfile } = useVoice();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchConversations = async () => {
    if (!user) return;
    try {
      // 1. Fetch conversations user belongs to
      const { data: memberData, error: memberError } = await supabase
        .from('conversation_members')
        .select('conversation_id')
        .eq('user_id', user.id);

      if (memberError || !memberData || memberData.length === 0) {
        setConversations([]);
        setLoading(false);
        setRefreshing(false);
        return;
      }

      const convIds = memberData.map(m => m.conversation_id);

      // 2. Fetch other member for each conversation
      const { data: allMembers } = await supabase
        .from('conversation_members')
        .select('conversation_id, user_id, profiles(*)')
        .in('conversation_id', convIds)
        .neq('user_id', user.id);

      // 3. Fetch latest message for each conversation
      const convList: Conversation[] = [];

      for (const convId of convIds) {
        const otherMember = allMembers?.find(m => m.conversation_id === convId);
        const { data: lastMessages } = await supabase
          .from('messages')
          .select('*')
          .eq('conversation_id', convId)
          .order('created_at', { ascending: false })
          .limit(1);

        convList.push({
          id: convId,
          created_at: '',
          updated_at: '',
          other_user: otherMember?.profiles as unknown as Profile,
          last_message: lastMessages?.[0],
        });
      }

      // Sort by latest message
      convList.sort((a, b) => {
        const timeA = a.last_message?.created_at ? new Date(a.last_message.created_at).getTime() : 0;
        const timeB = b.last_message?.created_at ? new Date(b.last_message.created_at).getTime() : 0;
        return timeB - timeA;
      });

      setConversations(convList);
    } catch (err) {
      console.error('Error fetching conversations:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchConversations();

    // Listen for realtime conversation updates
    const channel = supabase
      .channel('home_messages')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages' },
        () => {
          fetchConversations();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const onRefresh = () => {
    setRefreshing(true);
    fetchConversations();
  };

  const renderConversationItem = ({ item }: { item: Conversation }) => {
    const otherUser: Profile = item.other_user || {
      id: 'unknown',
      email: '',
      full_name: 'VoiceChat User',
      avatar_url: undefined,
    };
    const lastMsg = item.last_message;
    const isVoice = Boolean(lastMsg?.audio_url);

    return (
      <TouchableOpacity
        style={styles.chatItem}
        activeOpacity={0.7}
        onPress={() =>
          navigation.navigate('ChatDetail', {
            conversationId: item.id,
            otherUser,
          })
        }
      >
        <Avatar name={otherUser.full_name} avatarUrl={otherUser.avatar_url} size={50} />

        <View style={styles.chatInfo}>
          <View style={styles.chatHeaderRow}>
            <Text style={styles.userName} numberOfLines={1}>
              {otherUser.full_name}
            </Text>
            {lastMsg && (
              <Text style={styles.timeLabel}>
                {new Date(lastMsg.created_at).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </Text>
            )}
          </View>

          <View style={styles.chatSubRow}>
            {isVoice ? (
              <View style={styles.voicePreviewBadge}>
                <Mic size={13} color={COLORS.primaryLight} style={{ marginRight: 4 }} />
                <Text style={styles.voicePreviewText} numberOfLines={1}>
                  {lastMsg?.text || 'AI Voice Message'}
                </Text>
              </View>
            ) : (
              <Text style={styles.lastMessageText} numberOfLines={1}>
                {lastMsg?.text || 'No messages yet'}
              </Text>
            )}
          </View>
        </View>

        <ChevronRight size={18} color={COLORS.textMuted} />
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      {/* Top Bar */}
      <View style={styles.topBar}>
        <TouchableOpacity
          style={styles.userProfileButton}
          onPress={() => navigation.navigate('UserProfile')}
        >
          <Avatar
            name={profile?.full_name || 'User'}
            avatarUrl={profile?.avatar_url}
            size={38}
            hasVoiceClone={Boolean(voiceProfile)}
          />
          <View style={{ marginLeft: 10 }}>
            <Text style={styles.appTitle}>VoiceChat <Text style={styles.titleAccent}>AI</Text></Text>
            <Text style={styles.greetingText}>Hello, {profile?.full_name?.split(' ')[0] || 'User'}</Text>
          </View>
        </TouchableOpacity>

        <View style={styles.topActions}>
          <TouchableOpacity
            style={styles.actionIcon}
            onPress={() => navigation.navigate('UserSearch')}
          >
            <Search size={20} color={COLORS.textPrimary} />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionIcon}
            onPress={() => navigation.navigate('Settings')}
          >
            <Settings size={20} color={COLORS.textPrimary} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Voice Clone Status Banner */}
      <TouchableOpacity
        style={[
          styles.voiceBanner,
          voiceProfile ? styles.voiceBannerActive : styles.voiceBannerInactive,
        ]}
        onPress={() =>
          navigation.navigate(voiceProfile ? 'VoiceProfile' : 'VoiceSetup')
        }
      >
        <View style={styles.voiceBannerLeft}>
          <View
            style={[
              styles.bannerMicCircle,
              { backgroundColor: voiceProfile ? COLORS.primary : '#374151' },
            ]}
          >
            <Mic size={18} color="#FFFFFF" />
          </View>
          <View style={{ marginLeft: 10 }}>
            <Text style={styles.bannerTitle}>
              {voiceProfile ? 'AI Voice Active' : 'Setup AI Voice Clone'}
            </Text>
            <Text style={styles.bannerSubtitle}>
              {voiceProfile
                ? `Cloned as "${voiceProfile.voice_name}"`
                : 'Clone your voice to send spoken messages'}
            </Text>
          </View>
        </View>

        {voiceProfile ? (
          <CheckCircle2 size={20} color={COLORS.success} />
        ) : (
          <View style={styles.setupPill}>
            <Text style={styles.setupPillText}>Setup</Text>
          </View>
        )}
      </TouchableOpacity>

      {/* Conversations List */}
      {loading ? (
        <View style={styles.centerContainer}>
          <ActivityIndicator size="large" color={COLORS.primary} />
        </View>
      ) : conversations.length === 0 ? (
        <View style={styles.emptyContainer}>
          <View style={styles.emptyIconCircle}>
            <Mic size={36} color={COLORS.primaryLight} />
          </View>
          <Text style={styles.emptyTitle}>No Conversations Yet</Text>
          <Text style={styles.emptySubtitle}>
            Tap the button below or use search to start chatting with other users using your cloned AI voice!
          </Text>
          <TouchableOpacity
            style={styles.emptyButton}
            onPress={() => navigation.navigate('UserSearch')}
          >
            <MessageSquarePlus size={18} color="#FFFFFF" style={{ marginRight: 8 }} />
            <Text style={styles.emptyButtonText}>Start First Chat</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={conversations}
          keyExtractor={(item) => item.id}
          renderItem={renderConversationItem}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor={COLORS.primary}
            />
          }
          contentContainerStyle={{ paddingBottom: 90 }}
        />
      )}

      {/* Floating Action Button */}
      <TouchableOpacity
        style={styles.fab}
        onPress={() => navigation.navigate('UserSearch')}
        activeOpacity={0.85}
      >
        <MessageSquarePlus size={24} color="#FFFFFF" />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingTop: 48,
    paddingBottom: 14,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    backgroundColor: COLORS.surface,
  },
  userProfileButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  appTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: COLORS.textPrimary,
  },
  titleAccent: {
    color: COLORS.primaryLight,
  },
  greetingText: {
    fontSize: 12,
    color: COLORS.textMuted,
  },
  topActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  actionIcon: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: COLORS.surfaceLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  voiceBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginHorizontal: SPACING.md,
    marginVertical: 12,
    padding: 12,
    borderRadius: RADIUS.md,
    borderWidth: 1,
  },
  voiceBannerActive: {
    backgroundColor: 'rgba(99, 102, 241, 0.1)',
    borderColor: 'rgba(99, 102, 241, 0.3)',
  },
  voiceBannerInactive: {
    backgroundColor: COLORS.surface,
    borderColor: COLORS.border,
  },
  voiceBannerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  bannerMicCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bannerTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: COLORS.textPrimary,
  },
  bannerSubtitle: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  setupPill: {
    backgroundColor: COLORS.primary,
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: RADIUS.full,
  },
  setupPillText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  chatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.04)',
  },
  chatInfo: {
    flex: 1,
    marginLeft: 12,
    marginRight: 8,
  },
  chatHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  userName: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.textPrimary,
  },
  timeLabel: {
    fontSize: 11,
    color: COLORS.textMuted,
  },
  chatSubRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  lastMessageText: {
    fontSize: 13,
    color: COLORS.textSecondary,
  },
  voicePreviewBadge: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  voicePreviewText: {
    fontSize: 13,
    color: COLORS.primaryLight,
    fontWeight: '500',
  },
  centerContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: SPACING.xl,
  },
  emptyIconCircle: {
    width: 76,
    height: 76,
    borderRadius: 38,
    backgroundColor: COLORS.primaryGlow,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(99, 102, 241, 0.3)',
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: COLORS.textPrimary,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
  },
  emptyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.primary,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: RADIUS.md,
  },
  emptyButtonText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 15,
  },
  fab: {
    position: 'absolute',
    right: 20,
    bottom: 24,
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 8,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
  },
});
