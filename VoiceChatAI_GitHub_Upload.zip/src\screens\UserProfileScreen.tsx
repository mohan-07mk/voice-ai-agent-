import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
} from 'react-native';
import { ArrowLeft, LogOut, Check, Mic, User } from '../components/Icons';
import { useAuth } from '../context/AuthContext';
import { useVoice } from '../context/VoiceContext';
import { supabase } from '../api/supabase';
import { Avatar } from '../components/Avatar';
import { COLORS, SPACING, RADIUS } from '../constants/theme';

export const UserProfileScreen: React.FC<{ navigation: any }> = ({ navigation }) => {
  const { user, profile, signOut, refreshProfile } = useAuth();
  const { voiceProfile } = useVoice();
  const [fullName, setFullName] = useState(profile?.full_name || '');
  const [statusMessage, setStatusMessage] = useState(profile?.status_message || 'Using VoiceChat AI');
  const [saving, setSaving] = useState(false);

  const handleSaveProfile = async () => {
    if (!user) return;
    setSaving(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: fullName.trim(),
          status_message: statusMessage.trim(),
          updated_at: new Date().toISOString(),
        })
        .eq('id', user.id);

      if (error) {
        Alert.alert('Update Failed', error.message);
      } else {
        await refreshProfile();
        Alert.alert('Profile Saved', 'Your profile information has been updated.');
      }
    } catch (err: any) {
      Alert.alert('Error', err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleSignOut = () => {
    Alert.alert(
      'Sign Out',
      'Are you sure you want to sign out of VoiceChat AI?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Sign Out',
          style: 'destructive',
          onPress: async () => {
            await signOut();
            navigation.replace('Auth');
          },
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <ArrowLeft size={22} color={COLORS.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>User Profile</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.avatarSection}>
          <Avatar
            name={profile?.full_name || 'User'}
            avatarUrl={profile?.avatar_url}
            size={72}
            hasVoiceClone={Boolean(voiceProfile)}
          />
          <Text style={styles.emailText}>{profile?.email || user?.email}</Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.fieldLabel}>Full Name</Text>
          <TextInput
            style={styles.textInput}
            value={fullName}
            onChangeText={setFullName}
            placeholder="Your name"
            placeholderTextColor={COLORS.textMuted}
          />

          <Text style={[styles.fieldLabel, { marginTop: 14 }]}>Status Message</Text>
          <TextInput
            style={styles.textInput}
            value={statusMessage}
            onChangeText={setStatusMessage}
            placeholder="Status"
            placeholderTextColor={COLORS.textMuted}
          />

          <TouchableOpacity
            style={styles.saveButton}
            onPress={handleSaveProfile}
            disabled={saving}
          >
            <Check size={18} color="#FFFFFF" style={{ marginRight: 6 }} />
            <Text style={styles.saveButtonText}>
              {saving ? 'Saving...' : 'Save Changes'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Voice Profile Quick Access */}
        <TouchableOpacity
          style={styles.voiceCard}
          onPress={() =>
            navigation.navigate(voiceProfile ? 'VoiceProfile' : 'VoiceSetup')
          }
        >
          <View style={styles.voiceCardLeft}>
            <View style={styles.micCircle}>
              <Mic size={20} color="#FFFFFF" />
            </View>
            <View style={{ marginLeft: 12 }}>
              <Text style={styles.voiceCardTitle}>
                {voiceProfile ? 'AI Voice Clone Active' : 'Setup AI Voice Clone'}
              </Text>
              <Text style={styles.voiceCardSub}>
                {voiceProfile ? `"${voiceProfile.voice_name}"` : 'Record to clone your voice'}
              </Text>
            </View>
          </View>
        </TouchableOpacity>

        {/* Sign Out Button */}
        <TouchableOpacity style={styles.logoutButton} onPress={handleSignOut}>
          <LogOut size={18} color={COLORS.danger} style={{ marginRight: 8 }} />
          <Text style={styles.logoutText}>Sign Out</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingTop: 48,
    paddingBottom: 14,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    backgroundColor: COLORS.surface,
  },
  backButton: {
    padding: 6,
    marginRight: 10,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.textPrimary,
  },
  scrollContent: {
    padding: SPACING.md,
  },
  avatarSection: {
    alignItems: 'center',
    marginVertical: SPACING.lg,
  },
  emailText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginTop: 10,
  },
  card: {
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: RADIUS.lg,
    padding: SPACING.md,
    marginBottom: SPACING.lg,
  },
  fieldLabel: {
    fontSize: 12,
    color: COLORS.textMuted,
    marginBottom: 6,
    fontWeight: '600',
  },
  textInput: {
    backgroundColor: COLORS.surfaceLight,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: RADIUS.md,
    color: COLORS.textPrimary,
    paddingHorizontal: 14,
    height: 48,
    fontSize: 15,
  },
  saveButton: {
    backgroundColor: COLORS.primary,
    height: 46,
    borderRadius: RADIUS.md,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 18,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 15,
  },
  voiceCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: RADIUS.lg,
    padding: SPACING.md,
    marginBottom: SPACING.xl,
  },
  voiceCardLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  micCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  voiceCardTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: COLORS.textPrimary,
  },
  voiceCardSub: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(239, 68, 68, 0.25)',
    height: 50,
    borderRadius: RADIUS.md,
  },
  logoutText: {
    color: COLORS.danger,
    fontWeight: '700',
    fontSize: 15,
  },
});
